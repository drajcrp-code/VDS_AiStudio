package com.vds.creativestudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

// Change this number to set how many free images each user gets per day.
private const val DAILY_FREE_IMAGES = 10

private fun usedToday(ctx: Context): Int {
    val p = ctx.getSharedPreferences("usage", Context.MODE_PRIVATE)
    return if (p.getString("day", "") == LocalDate.now().toString()) p.getInt("images", 0) else 0
}

private fun addUse(ctx: Context) {
    val n = usedToday(ctx) + 1
    ctx.getSharedPreferences("usage", Context.MODE_PRIVATE).edit()
        .putString("day", LocalDate.now().toString()).putInt("images", n).apply()
}

// Free image service (no key needed). Swap this function later to use another provider.
private fun fetchImage(prompt: String): Bitmap? {
    val url = "https://image.pollinations.ai/prompt/" + Uri.encode(prompt) +
        "?width=1024&height=1024&model=flux&nologo=true&seed=" + (0..999999).random()
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 30000
    c.readTimeout = 120000
    c.setRequestProperty("User-Agent", "CreativeStudio")
    return try {
        c.inputStream.use { BitmapFactory.decodeStream(it) }
    } finally {
        c.disconnect()
    }
}

@Composable
fun ImageScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("Realistic") }
    var used by remember { mutableIntStateOf(usedToday(ctx)) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    val left = DAILY_FREE_IMAGES - used

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text("Generate Image", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        Spacer(Modifier.height(12.dp))
        Text("Free images today: $left of $DAILY_FREE_IMAGES left", fontSize = 14.sp, color = Muted)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = prompt, onValueChange = { prompt = it },
            modifier = Modifier.fillMaxWidth().height(110.dp),
            shape = RoundedCornerShape(16.dp),
            placeholder = { Text("Describe the image you want...") }
        )
        Spacer(Modifier.height(12.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Realistic", "Anime", "Cinematic", "3D").forEach { s ->
                FilterChip(selected = style == s, onClick = { style = s }, label = { Text(s) })
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (prompt.isBlank() || loading) {
                    // nothing to do
                } else if (left <= 0) {
                    error = "Free limit reached for today."
                } else {
                    loading = true
                    error = null
                    scope.launch {
                        try {
                            val bmp = withContext(Dispatchers.IO) { fetchImage("$prompt, $style style") }
                            if (bmp != null) {
                                image = bmp.asImageBitmap()
                                addUse(ctx)
                                used = usedToday(ctx)
                            } else {
                                error = "Could not create the image. Try again."
                            }
                        } catch (e: Exception) {
                            error = "Network error. Check your internet and try again."
                        }
                        loading = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(if (loading) "Creating..." else "Generate", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        if (loading) {
            Box(Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        error?.let { Text(it, color = Color(0xFFFF9A9A), fontSize = 14.sp) }
        image?.let {
            Image(
                bitmap = it, contentDescription = "Generated image",
                modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp))
            )
        }
    }
}
