package com.vds.creativestudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import kotlin.coroutines.coroutineContext
import kotlin.coroutines.resume
import kotlin.math.roundToInt

class Scene(val narration: String, val image: String, val video: String)
class Hero(val name: String, val look: String)
class Script(val heroes: List<Hero>, val scenes: List<Scene>)

// ---- Reading what the user wrote in the brief ----
fun detectVertical(t: String): Boolean? = when {
    Regex("9\\s*:\\s*16|\\bvertical\\b|\\bshorts?\\b|\\breels?\\b", RegexOption.IGNORE_CASE).containsMatchIn(t) -> true
    Regex("16\\s*:\\s*9|\\blandscape\\b|\\bhorizontal\\b", RegexOption.IGNORE_CASE).containsMatchIn(t) -> false
    else -> null
}

fun detectStyle(t: String): String? = when {
    Regex("\\b3\\s*d\\b", RegexOption.IGNORE_CASE).containsMatchIn(t) -> "3D"
    Regex("anime", RegexOption.IGNORE_CASE).containsMatchIn(t) -> "Anime"
    Regex("realistic|photorealistic", RegexOption.IGNORE_CASE).containsMatchIn(t) -> "Realistic"
    Regex("cinematic", RegexOption.IGNORE_CASE).containsMatchIn(t) -> "Cinematic"
    else -> null
}

fun detectNature(t: String): Boolean =
    Regex("\\b(jungle|forest|nature|birds?|animals?|elephants?|river|rain)\\b", RegexOption.IGNORE_CASE).containsMatchIn(t)

private fun detectSceneCount(t: String): Int? =
    Regex("(\\d+)\\s*(?:continuous\\s*)?scenes", RegexOption.IGNORE_CASE).find(t)
        ?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(2, 12)

private fun detectSceneSeconds(t: String): Int? {
    val a = Regex("scenes?\\s*(?:of|at)\\s*(\\d+)\\s*[- ]?\\s*seconds?", RegexOption.IGNORE_CASE).find(t)
    val b = Regex("(\\d+)\\s*[- ]?\\s*seconds?\\s*each", RegexOption.IGNORE_CASE).find(t)
    return (a ?: b)?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(3, 12)
}

private fun styleWords(style: String) = when (style) {
    "3D" -> "colorful 3D animated children's movie style, soft lighting, expressive characters"
    "Anime" -> "anime style, vivid colors"
    "Realistic" -> "realistic photo style, natural light"
    else -> "cinematic film style, dramatic lighting"
}

private fun parseScript(text: String): Script? {
    val a = text.indexOf('{')
    val b = text.lastIndexOf('}')
    if (a < 0 || b <= a) return null
    return try {
        val root = JSONObject(text.substring(a, b + 1))
        val heroes = ArrayList<Hero>()
        val ha = root.optJSONArray("characters")
        if (ha != null) {
            for (i in 0 until ha.length()) {
                val o = ha.getJSONObject(i)
                val nm = o.optString("name", "").trim()
                val lk = o.optString("look", "").trim()
                if (nm.isNotEmpty() && lk.isNotEmpty()) heroes.add(Hero(nm, lk))
            }
        }
        val arr = root.getJSONArray("scenes")
        val scenes = (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val n = o.optString("narration", "").trim()
            val im = o.optString("image", "").trim()
            val vd = o.optString("video", "").trim()
            val image = if (im.isEmpty()) n else im
            if (n.isEmpty()) null else Scene(n, image, if (vd.isEmpty()) image else vd)
        }.take(12)
        if (scenes.isEmpty()) null else Script(heroes, scenes)
    } catch (e: Exception) {
        null
    }
}

// Makes sure every character is described the same way in every picture.
private fun withLooks(s: Scene, heroes: List<Hero>): Scene {
    fun fix(t: String): String {
        var x = t
        for (h in heroes) {
            if (x.contains(h.name, ignoreCase = true) && !x.contains(h.look.take(25), ignoreCase = true)) {
                x += ". ${h.name}: ${h.look}"
            }
        }
        return x
    }
    return Scene(s.narration, fix(s.image), fix(s.video))
}

// Used only when the user says their text is already the finished story.
private fun fallbackScenes(idea: String): List<Scene> {
    val parts = idea.split(Regex("(?<=[.!?])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
    val chunks = ArrayList<String>()
    var cur = ""
    for (p in parts) {
        if (cur.isEmpty()) {
            cur = p
        } else if ((cur + " " + p).split(" ").size <= 22) {
            cur = "$cur $p"
        } else {
            chunks.add(cur)
            cur = p
        }
    }
    if (cur.isNotEmpty()) chunks.add(cur)
    return chunks.take(10).map { Scene(it, it, it) }
}

private fun scriptInstruction(idea: String, style: String, avatarDesc: String, n: Int, secs: Double): String {
    val words = (secs * 2.2).roundToInt()
    return "You write scripts for narrated videos. The user's brief is below. It may contain instructions about format, length and sound: " +
        "use it to write the story, but never read the instructions out loud.\n" +
        "BRIEF: \"$idea\"\n" +
        "Write exactly $n scenes. Each scene lasts about ${secs.roundToInt()} seconds, so each narration needs about $words words " +
        "(clear, simple, spoken sentences, in the same language as the brief). " +
        "If the brief asks for a moral or a closing message, put it in the last scene. " +
        "First list every character who appears, with a full visual description (species or age, colors, clothes, special marks). " +
        "Then for each scene write an image prompt for ONE still picture in ${styleWords(style)}, and a video prompt for the same moment that says what moves (what the characters do and how the camera moves). " +
        "In every image prompt and video prompt repeat the full visual description of each character who appears, word for word, so they look identical every time. " +
        "No text, letters, captions or watermarks in the pictures. " +
        "If the story needs a person and the brief does not describe one, you may use this person: $avatarDesc. " +
        "Reply with JSON only: {\"characters\":[{\"name\":\"...\",\"look\":\"...\"}],\"scenes\":[{\"narration\":\"...\",\"image\":\"...\",\"video\":\"...\"}]}"
}

private suspend fun initTts(ctx: Context): TextToSpeech {
    val ready = CompletableDeferred<Boolean>()
    lateinit var tts: TextToSpeech
    withContext(Dispatchers.Main) {
        tts = TextToSpeech(ctx) { status -> ready.complete(status == TextToSpeech.SUCCESS) }
    }
    if (!ready.await()) {
        tts.shutdown()
        throw IllegalStateException("Text to speech is not available on this phone.")
    }
    return tts
}

private suspend fun synth(tts: TextToSpeech, text: String, f: File): Boolean = suspendCancellableCoroutine { cont ->
    val id = "u" + System.nanoTime()
    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) {
            if (utteranceId == id && cont.isActive) cont.resume(true)
        }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            if (utteranceId == id && cont.isActive) cont.resume(false)
        }
        override fun onError(utteranceId: String?, errorCode: Int) {
            if (utteranceId == id && cont.isActive) cont.resume(false)
        }
    })
    f.delete()
    val r = tts.synthesizeToFile(text, Bundle(), f, id)
    if (r != TextToSpeech.SUCCESS && cont.isActive) cont.resume(false)
}

private val framePaint = Paint(Paint.FILTER_BITMAP_FLAG)

// Slow zoom ("Ken Burns") so a still picture feels alive.
private fun drawKenBurns(c: Canvas, bmp: Bitmap, w: Int, h: Int, q: Float) {
    val target = w.toFloat() / h
    var cw = bmp.width.toFloat()
    var ch = cw / target
    if (ch > bmp.height) {
        ch = bmp.height.toFloat()
        cw = ch * target
    }
    val s = 1f + 0.12f * q
    val zw = cw / s
    val zh = ch / s
    val cx = bmp.width / 2f
    val cy = bmp.height / 2f
    val src = Rect((cx - zw / 2).toInt(), (cy - zh / 2).toInt(), (cx + zw / 2).toInt(), (cy + zh / 2).toInt())
    c.drawBitmap(bmp, src, Rect(0, 0, w, h), framePaint)
}

private fun sampleAt(b: ByteArray, i: Int): Int = (b[2 * i].toInt() and 255) or (b[2 * i + 1].toInt() shl 8)

// Mixes a looping background sound under the narration.
private fun mixLoop(target: ByteArray, src: Pcm, rate: Int, gain: Float) {
    val s = resampleTo(src, rate)
    val total = target.size / 2
    val srcN = s.size / 2
    if (srcN == 0 || total == 0) return
    val fadeIn = (0.5 * rate).toInt().coerceAtLeast(1)
    val fadeOut = (2.0 * rate).toInt().coerceAtLeast(1)
    for (i in 0 until total) {
        val fade = minOf(1f, i / fadeIn.toFloat()) * minOf(1f, (total - i) / fadeOut.toFloat())
        val m = (sampleAt(target, i) + sampleAt(s, i % srcN) * gain * fade).toInt().coerceIn(-32768, 32767)
        target[2 * i] = (m and 255).toByte()
        target[2 * i + 1] = ((m shr 8) and 255).toByte()
    }
}

private fun rawPcm(ctx: Context, id: Int): Pcm? =
    try { ctx.resources.openRawResource(id).use { readWavPcm(it.readBytes()) } } catch (e: Exception) { null }

// Runs the whole 60 second project in the background and reports progress to the screen.
class ProjectState {
    var running by mutableStateOf(false)
    var status by mutableStateOf("")
    var progress by mutableFloatStateOf(0f)
    var error by mutableStateOf<String?>(null)
    var note by mutableStateOf("")
    var script by mutableStateOf("")
    var resultPath by mutableStateOf<String?>(null)
    var resultVertical by mutableStateOf(false)
    private var job: Job? = null
    private val temp = ArrayList<File>()

    fun cancel() { job?.cancel() }

    fun start(
        ctx: Context, scope: CoroutineScope, idea: String, avatarIndex: Int, vertical: Boolean,
        style: String, music: Boolean, nature: Boolean, useMyText: Boolean, animated: Boolean
    ) {
        if (running) return
        running = true
        error = null
        note = ""
        script = ""
        resultPath = null
        resultVertical = vertical
        progress = 0f
        status = "Starting..."
        job = scope.launch(Dispatchers.IO) {
            try {
                resultPath = produce(ctx, idea, avatarIndex, vertical, style, music, nature, useMyText, animated)
                status = "Done"
                progress = 1f
            } catch (e: CancellationException) {
                error = "Cancelled."
            } catch (e: IllegalStateException) {
                error = e.message ?: "Something went wrong."
            } catch (e: Throwable) {
                error = "Could not finish the video (" + (e.message ?: e.javaClass.simpleName) + ")."
            } finally {
                temp.forEach { try { it.delete() } catch (x: Exception) { } }
                temp.clear()
                running = false
            }
        }
    }

    private fun tmp(ctx: Context, name: String): File {
        val f = File(ctx.cacheDir, name)
        temp.add(f)
        return f
    }

    private suspend fun produce(
        ctx: Context, idea: String, avatarIndex: Int, vertical: Boolean, style: String,
        music: Boolean, nature: Boolean, useMyText: Boolean, animated: Boolean
    ): String {
        val w = if (vertical) 720 else 1280
        val h = if (vertical) 1280 else 720
        val fps = 15
        val avatar = Store.avatar(ctx, avatarIndex)
        val akey = Store.geminiKey(ctx)
        val ikey = Store.imageKey(ctx)

        // 1. Look of the avatar (an optional extra character)
        status = "Preparing the character..."
        var avatarDesc = "a ${avatar.age} year old ${avatar.sex.lowercase()} named ${avatar.name}"
        val photo = Store.avatarBitmap(ctx, avatarIndex)
        if (photo != null && akey.isNotBlank() && !useMyText) {
            try {
                val look = geminiAsk(
                    akey,
                    "Describe this person's look in one short sentence for an AI image generator (age, hair, skin tone, clothes). Reply with the sentence only.",
                    photo
                )
                avatarDesc = look.trim().trim('"')
            } catch (e: GeminiException) {
                note = "The avatar photo could not be read, so age and sex were used."
            }
        }
        coroutineContext.ensureActive()

        // 2. The script
        status = "Writing the script..."
        progress = 0.03f
        val countWanted = detectSceneCount(idea)
        val secsWanted = detectSceneSeconds(idea)
        val n = countWanted ?: (if (secsWanted != null) (60.0 / secsWanted).roundToInt().coerceIn(2, 12) else 9)
        var perScene = (secsWanted?.toDouble() ?: (60.0 / n)).coerceIn(3.0, 12.0)
        var scenes: List<Scene>
        if (useMyText) {
            scenes = fallbackScenes(idea)
            if (scenes.isEmpty()) throw IllegalStateException("Please type your story first.")
            perScene = (60.0 / scenes.size).coerceIn(4.0, 12.0)
        } else {
            if (akey.isBlank()) {
                throw IllegalStateException("The assistant is needed to turn your brief into a script. Add its key in You > Settings, or choose \"Use my text as the story\".")
            }
            var parsed: Script? = null
            var why = ""
            for (attempt in 0..1) {
                coroutineContext.ensureActive()
                try {
                    parsed = parseScript(geminiAsk(akey, scriptInstruction(idea, style, avatarDesc, n, perScene), null, false, true))
                    if (parsed != null) break
                    why = "The script came back in the wrong format."
                } catch (e: GeminiException) {
                    why = e.message ?: ""
                    break
                }
            }
            val p = parsed ?: throw IllegalStateException(
                "The assistant could not write the script. $why Try again later, or paste the finished story and choose \"Use my text as the story\"."
            )
            scenes = p.scenes.map { withLooks(it, p.heroes) }
        }
        script = scenes.withIndex().joinToString("\n\n") { "Scene ${it.index + 1}: ${it.value.narration}" }
        val count = scenes.size

        // 3a. Animated clips (optional): one moving clip per scene
        val clips = arrayOfNulls<String>(count)
        if (animated) {
            if (ikey.isBlank()) {
                throw IllegalStateException("Animated clips need the images and video key. Add it in You > Settings, or choose still pictures.")
            }
            var failed = 0
            for ((i, s) in scenes.withIndex()) {
                coroutineContext.ensureActive()
                if (failed >= 2) break
                status = "Animating scene ${i + 1} of $count... (a few minutes each)"
                progress = 0.05f + 0.45f * i / count
                val secsClip = perScene.roundToInt().coerceIn(2, 10)
                val prompt = "${s.video}, ${styleWords(style)}, smooth natural motion, no text, no captions"
                try {
                    val path = downloadClip(ctx, clipUrl(prompt, "seedance", secsClip, vertical, ikey), ikey)
                    temp.add(File(path))
                    clips[i] = path
                } catch (e: KeyException) {
                    throw IllegalStateException("The images and video key was not accepted. Check it in You > Settings.")
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failed++
                    val why = if (e is BusyException) "your free video allowance may be used up" else (e.message ?: "the video service failed")
                    note = (note + " Scene ${i + 1} could not be animated ($why), so a still picture is used.").trim()
                    if (failed >= 2) note = (note + " Animation was stopped, the other scenes use still pictures.").trim()
                }
            }
        }

        // 3b. Still pictures (all scenes, or the scenes that have no clip). One fixed seed helps characters look alike.
        val picStart = if (animated) 0.50f else 0.05f
        val picEnd = if (animated) 0.56f else 0.45f
        val seed = (0..999999).random()
        val stills = arrayOfNulls<Bitmap>(count)
        var lastStill: Bitmap? = null
        for ((i, s) in scenes.withIndex()) {
            coroutineContext.ensureActive()
            if (clips[i] != null) continue
            status = "Making picture ${i + 1} of $count..."
            progress = picStart + (picEnd - picStart) * i / count
            val prompt = "${s.image}, ${styleWords(style)}, high quality, no text, no letters, no captions".take(900)
            val bmp = try {
                fetchImage(prompt, ikey, w, h, 6, 8000L, seed)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastStill ?: throw IllegalStateException("The picture service did not answer. Wait a minute and try again.")
            }
            stills[i] = bmp
            lastStill = bmp
        }

        // 4. The voice
        status = "Preparing the voice..."
        progress = picEnd + 0.01f
        val tts = initTts(ctx)
        val pcms = ArrayList<Pcm>()
        try {
            val v = tts.voices?.firstOrNull { it.name == avatar.voice }
            if (v != null) tts.setVoice(v)
            tts.setPitch(avatar.pitch)
            tts.setSpeechRate(avatar.speed)
            for ((i, s) in scenes.withIndex()) {
                coroutineContext.ensureActive()
                status = "Recording the voice ${i + 1} of $count..."
                progress = picEnd + 0.01f + 0.08f * i / count
                val f = tmp(ctx, "scene_$i.wav")
                val ok = synth(tts, s.narration.take(1500), f)
                val pcm = if (ok) readWavPcm(f) else null
                if (pcm == null) throw IllegalStateException("The phone voice could not record the narration.")
                pcms.add(pcm)
            }
        } finally {
            tts.shutdown()
        }

        // 5. Timing: each scene lasts as long as its narration (at least the planned time)
        val rate = pcms[0].sampleRate
        val framesPer = pcms.map {
            (maxOf(it.data.size / 2.0 / it.sampleRate + 0.5, perScene) * fps).roundToInt().coerceAtLeast(1)
        }
        val total = framesPer.sum()

        // 6. The video: moving clips where we have them, pictures with a slow zoom for the rest
        val vStart = picEnd + 0.09f
        val vSpan = 0.90f - vStart
        val vfile = tmp(ctx, "project_video.mp4")
        val writer = VideoWriter(vfile, w, h, fps)
        try {
            val frame = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(frame)
            val pixels = IntArray(w * h)
            var done = 0
            for (i in 0 until count) {
                val c = framesPer[i]
                val reader = clips[i]?.let { p -> try { ClipReader(p) } catch (e: Exception) { null } }
                try {
                    for (k in 0 until c) {
                        if (k % 15 == 0) coroutineContext.ensureActive()
                        var drawn = false
                        if (reader != null) {
                            val tUs = minOf(k * 1_000_000L / fps, maxOf(0L, reader.durationUs - 50_000L))
                            val fb = reader.frame(tUs)
                            if (fb != null) {
                                drawKenBurns(canvas, fb, w, h, 0f)
                                fb.recycle()
                                drawn = true
                            }
                        }
                        if (!drawn) {
                            val still = stills[i]
                            if (still != null) {
                                val p = if (c > 1) k.toFloat() / (c - 1) else 0f
                                drawKenBurns(canvas, still, w, h, if (i % 2 == 0) p else 1f - p)
                            }
                        }
                        frame.getPixels(pixels, 0, w, 0, 0, w, h)
                        writer.addFrame(pixels)
                        done++
                        if (done % 10 == 0) {
                            progress = vStart + vSpan * done / total
                            status = "Building the video... ${100 * done / total}%"
                        }
                    }
                } finally {
                    reader?.close()
                }
            }
            writer.finish()
        } catch (e: Throwable) {
            writer.release()
            throw e
        }

        // 7. The sound: narration lined up with the scenes, plus music and nature sounds
        status = "Adding the voice and sounds..."
        progress = 0.92f
        val blocks = ArrayList<ByteArray>()
        for ((i, p) in pcms.withIndex()) {
            val data = resampleTo(p, rate)
            val block = ByteArray((framesPer[i].toLong() * rate / fps).toInt() * 2)
            System.arraycopy(data, 0, block, 0, minOf(data.size, block.size))
            blocks.add(block)
        }
        val all = ByteArray(blocks.sumOf { it.size })
        var pos = 0
        for (b in blocks) {
            System.arraycopy(b, 0, all, pos, b.size)
            pos += b.size
        }
        if (music) rawPcm(ctx, R.raw.bgm_happy)?.let { mixLoop(all, it, rate, 0.16f) }
        if (nature) rawPcm(ctx, R.raw.amb_jungle)?.let { mixLoop(all, it, rate, 0.30f) }
        val afile = tmp(ctx, "project_audio.m4a")
        encodeAac(all, rate, afile)
        coroutineContext.ensureActive()

        // 8. Join video and sound
        status = "Saving the final video..."
        progress = 0.96f
        val out = File(ctx.cacheDir, "project_${System.currentTimeMillis()}.mp4")
        muxFinal(vfile, afile, out)
        try { Library.saveClip(ctx, out.path, idea) } catch (e: Exception) { }
        return out.path
    }
}
