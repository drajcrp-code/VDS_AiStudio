package com.vds.creativestudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import kotlin.coroutines.coroutineContext
import kotlin.coroutines.resume
import kotlin.math.roundToInt

class Scene(val narration: String, val image: String)

private fun parseScenes(text: String): List<Scene> {
    val a = text.indexOf('{')
    val b = text.lastIndexOf('}')
    if (a < 0 || b <= a) return emptyList()
    return try {
        val arr = JSONObject(text.substring(a, b + 1)).getJSONArray("scenes")
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val n = o.optString("narration", "").trim()
            val im = o.optString("image", "").trim()
            if (n.isEmpty()) null else Scene(n, if (im.isEmpty()) n else im)
        }.take(12)
    } catch (e: Exception) {
        emptyList()
    }
}

// If the assistant is not available, the user's own text is cut into scenes.
private fun fallbackScenes(idea: String): List<Scene> {
    val parts = idea.split(Regex("(?<=[.!?])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
    val chunks = ArrayList<String>()
    var cur = ""
    for (p in parts) {
        if (cur.isEmpty()) {
            cur = p
        } else if ((cur + " " + p).split(" ").size <= 22) {
            cur = "$cur $p"
        } else {
            chunks.add(cur)
            cur = p
        }
    }
    if (cur.isNotEmpty()) chunks.add(cur)
    return chunks.take(10).map { Scene(it, it) }
}

private fun scriptInstruction(idea: String, style: String, charDesc: String) =
    "Write a narrated video of about 60 seconds on this idea: \"$idea\". " +
        "Make exactly 9 scenes. For each scene write the narration (14 to 18 words, simple clear sentences, in the same language as the idea) " +
        "and one image prompt describing a single still picture for an AI image generator in $style style. " +
        "The main character is $charDesc. Include the character in the image prompt whenever he or she appears, always with the same look. " +
        "Do not put text, captions, aspect ratio or watermarks in the images. " +
        "Reply with JSON only, no markdown, exactly like {\"scenes\":[{\"narration\":\"...\",\"image\":\"...\"}]}"

private suspend fun initTts(ctx: Context): TextToSpeech {
    val ready = CompletableDeferred<Boolean>()
    lateinit var tts: TextToSpeech
    withContext(Dispatchers.Main) {
        tts = TextToSpeech(ctx) { status -> ready.complete(status == TextToSpeech.SUCCESS) }
    }
    if (!ready.await()) {
        tts.shutdown()
        throw IllegalStateException("Text to speech is not available on this phone.")
    }
    return tts
}

private suspend fun synth(tts: TextToSpeech, text: String, f: File): Boolean = suspendCancellableCoroutine { cont ->
    val id = "u" + System.nanoTime()
    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) {
            if (utteranceId == id && cont.isActive) cont.resume(true)
        }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            if (utteranceId == id && cont.isActive) cont.resume(false)
        }
        override fun onError(utteranceId: String?, errorCode: Int) {
            if (utteranceId == id && cont.isActive) cont.resume(false)
        }
    })
    f.delete()
    val r = tts.synthesizeToFile(text, Bundle(), f, id)
    if (r != TextToSpeech.SUCCESS && cont.isActive) cont.resume(false)
}

private val framePaint = Paint(Paint.FILTER_BITMAP_FLAG)

// Slow zoom ("Ken Burns") so a still picture feels alive.
private fun drawKenBurns(c: Canvas, bmp: Bitmap, w: Int, h: Int, q: Float) {
    val target = w.toFloat() / h
    var cw = bmp.width.toFloat()
    var ch = cw / target
    if (ch > bmp.height) {
        ch = bmp.height.toFloat()
        cw = ch * target
    }
    val s = 1f + 0.12f * q
    val zw = cw / s
    val zh = ch / s
    val cx = bmp.width / 2f
    val cy = bmp.height / 2f
    val src = Rect((cx - zw / 2).toInt(), (cy - zh / 2).toInt(), (cx + zw / 2).toInt(), (cy + zh / 2).toInt())
    c.drawBitmap(bmp, src, Rect(0, 0, w, h), framePaint)
}

// Runs the whole 60 second project in the background and reports progress to the screen.
class ProjectState {
    var running by mutableStateOf(false)
    var status by mutableStateOf("")
    var progress by mutableFloatStateOf(0f)
    var error by mutableStateOf<String?>(null)
    var note by mutableStateOf("")
    var resultPath by mutableStateOf<String?>(null)
    private var job: Job? = null
    private val temp = ArrayList<File>()

    fun cancel() { job?.cancel() }

    fun start(ctx: Context, scope: CoroutineScope, idea: String, avatarIndex: Int, vertical: Boolean, style: String) {
        if (running) return
        running = true
        error = null
        note = ""
        resultPath = null
        progress = 0f
        status = "Starting..."
        job = scope.launch(Dispatchers.IO) {
            try {
                resultPath = produce(ctx, idea, avatarIndex, vertical, style)
                status = "Done"
                progress = 1f
            } catch (e: CancellationException) {
                error = "Cancelled."
            } catch (e: IllegalStateException) {
                error = e.message ?: "Something went wrong."
            } catch (e: Throwable) {
                error = "Could not finish the video (" + (e.message ?: e.javaClass.simpleName) + ")."
            } finally {
                temp.forEach { try { it.delete() } catch (x: Exception) { } }
                temp.clear()
                running = false
            }
        }
    }

    private fun tmp(ctx: Context, name: String): File {
        val f = File(ctx.cacheDir, name)
        temp.add(f)
        return f
    }

    private suspend fun produce(ctx: Context, idea: String, avatarIndex: Int, vertical: Boolean, style: String): String {
        val w = if (vertical) 720 else 1280
        val h = if (vertical) 1280 else 720
        val fps = 15
        val avatar = Store.avatar(ctx, avatarIndex)
        val akey = Store.geminiKey(ctx)
        val ikey = Store.imageKey(ctx)

        // 1. How the main character looks
        status = "Preparing the character..."
        var charDesc = "a ${avatar.age} year old ${avatar.sex.lowercase()} named ${avatar.name}"
        val photo = Store.avatarBitmap(ctx, avatarIndex)
        if (photo != null && akey.isNotBlank()) {
            try {
                val look = geminiAsk(
                    akey,
                    "Describe this person's look in one short sentence for an AI image generator (age, hair, skin tone, clothes). Reply with the sentence only.",
                    photo
                )
                charDesc = look.trim().trim('"')
            } catch (e: GeminiException) {
                note = "The avatar photo could not be read, so age and sex were used."
            }
        }
        coroutineContext.ensureActive()

        // 2. The script
        status = "Writing the script..."
        progress = 0.03f
        var scenes: List<Scene> = emptyList()
        if (akey.isNotBlank()) {
            try {
                scenes = parseScenes(geminiAsk(akey, scriptInstruction(idea, style, charDesc)))
            } catch (e: GeminiException) {
                note = (note + " " + (e.message ?: "")).trim()
            }
        }
        if (scenes.isEmpty()) {
            scenes = fallbackScenes(idea)
            note = (note + " The assistant could not write the script, so your own text was split into scenes.").trim()
        }
        if (scenes.isEmpty()) throw IllegalStateException("Please type your idea first.")
        val n = scenes.size

        // 3. The pictures
        val bitmaps = ArrayList<Bitmap>()
        for ((i, s) in scenes.withIndex()) {
            coroutineContext.ensureActive()
            status = "Making picture ${i + 1} of $n..."
            progress = 0.05f + 0.40f * i / n
            val prompt = "${s.image}, $style style".take(900)
            val bmp = try {
                fetchImage(prompt, ikey, w, h, 6, 8000L)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (bitmaps.isNotEmpty()) bitmaps.last()
                else throw IllegalStateException("The picture service did not answer. Wait a minute and try again.")
            }
            bitmaps.add(bmp)
        }

        // 4. The voice
        status = "Preparing the voice..."
        progress = 0.46f
        val tts = initTts(ctx)
        val pcms = ArrayList<Pcm>()
        try {
            val v = tts.voices?.firstOrNull { it.name == avatar.voice }
            if (v != null) tts.setVoice(v)
            tts.setPitch(avatar.pitch)
            tts.setSpeechRate(avatar.speed)
            for ((i, s) in scenes.withIndex()) {
                coroutineContext.ensureActive()
                status = "Recording the voice ${i + 1} of $n..."
                progress = 0.46f + 0.09f * i / n
                val f = tmp(ctx, "scene_$i.wav")
                val ok = synth(tts, s.narration.take(1500), f)
                val pcm = if (ok) readWavPcm(f) else null
                if (pcm == null) throw IllegalStateException("The phone voice could not record the narration.")
                pcms.add(pcm)
            }
        } finally {
            tts.shutdown()
        }

        // 5. Timing: each scene lasts as long as its narration plus half a second
        val rate = pcms[0].sampleRate
        val framesPer = pcms.map { ((it.data.size / 2.0 / it.sampleRate + 0.5) * fps).roundToInt().coerceAtLeast(1) }
        val total = framesPer.sum()

        // 6. The video (pictures with a slow zoom)
        val vfile = tmp(ctx, "project_video.mp4")
        val writer = VideoWriter(vfile, w, h, fps)
        try {
            val frame = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(frame)
            val pixels = IntArray(w * h)
            var done = 0
            for ((i, bmp) in bitmaps.withIndex()) {
                val count = framesPer[i]
                for (k in 0 until count) {
                    if (k % 15 == 0) coroutineContext.ensureActive()
                    val p = if (count > 1) k.toFloat() / (count - 1) else 0f
                    drawKenBurns(canvas, bmp, w, h, if (i % 2 == 0) p else 1f - p)
                    frame.getPixels(pixels, 0, w, 0, 0, w, h)
                    writer.addFrame(pixels)
                    done++
                    if (done % 10 == 0) {
                        progress = 0.55f + 0.35f * done / total
                        status = "Building the video... ${100 * done / total}%"
                    }
                }
            }
            writer.finish()
        } catch (e: Throwable) {
            writer.release()
            throw e
        }

        // 7. The sound track, lined up with the scenes
        status = "Adding the voice..."
        progress = 0.91f
        val blocks = ArrayList<ByteArray>()
        for ((i, p) in pcms.withIndex()) {
            val data = resampleTo(p, rate)
            val block = ByteArray((framesPer[i].toLong() * rate / fps).toInt() * 2)
            System.arraycopy(data, 0, block, 0, minOf(data.size, block.size))
            blocks.add(block)
        }
        val all = ByteArray(blocks.sumOf { it.size })
        var pos = 0
        for (b in blocks) {
            System.arraycopy(b, 0, all, pos, b.size)
            pos += b.size
        }
        val afile = tmp(ctx, "project_audio.m4a")
        encodeAac(all, rate, afile)
        coroutineContext.ensureActive()

        // 8. Join video and sound
        status = "Saving the final video..."
        progress = 0.96f
        val out = File(ctx.cacheDir, "project_${System.currentTimeMillis()}.mp4")
        muxFinal(vfile, afile, out)
        try { Library.saveClip(ctx, out.path, idea) } catch (e: Exception) { }
        return out.path
    }
}
