package com.vds.creativestudio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import java.io.File

// Saves into the phone gallery. This works on Android 10 and newer.
fun saveImageToGallery(ctx: Context, bmp: Bitmap): Boolean {
    if (Build.VERSION.SDK_INT < 29) return false
    return try {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "VDSAistudio_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VDSAistudio")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return false
        ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        true
    } catch (e: Exception) {
        false
    }
}

fun saveVideoToGallery(ctx: Context, path: String): Boolean {
    if (Build.VERSION.SDK_INT < 29) return false
    return try {
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VDSAistudio_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VDSAistudio")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return false
        ctx.contentResolver.openOutputStream(uri)?.use { out -> File(path).inputStream().use { it.copyTo(out) } }
        true
    } catch (e: Exception) {
        false
    }
}
