package com.vds.creativestudio

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private class Feat(val title: String, val text: String, val icon: ImageVector, val c1: Color, val c2: Color)

@Composable
fun FeatureCarousel() {
    val feats = remember {
        listOf(
            Feat("Generate Image", "Turn words or a reference photo into pictures. Free every day.",
                Icons.Filled.Image, Color(0xFF3F6AD8), Color(0xFF7040C0)),
            Feat("Generate Video", "Short AI clips up to 8 seconds. Coming soon.",
                Icons.Filled.Videocam, Color(0xFF5A4BD6), Color(0xFF9036B8)),
            Feat("Create Project", "One prompt to a 60 second video with your character and voice. Coming soon.",
                Icons.Filled.Add, Color(0xFF4B5BD6), Color(0xFF7A3EC8)),
            Feat("Avatars and Voices", "Design characters with a name, age, sex and voice you can hear.",
                Icons.Filled.Face, Color(0xFF2F7A8A), Color(0xFF4B5BD6)),
            Feat("Ask Gemini", "Get ideas, scripts and answers without leaving the app.",
                Icons.Filled.AutoAwesome, Color(0xFF8A3FB8), Color(0xFF3F6AD8))
        )
    }
    val state = rememberPagerState(pageCount = { feats.size })
    LaunchedEffect(Unit) {
        while (true) {
            delay(4000)
            state.animateScrollToPage((state.currentPage + 1) % feats.size)
        }
    }
    HorizontalPager(
        state = state,
        contentPadding = PaddingValues(horizontal = 40.dp),
        pageSpacing = 4.dp,
        modifier = Modifier.fillMaxWidth().height(180.dp)
    ) { page ->
        val offset = (state.currentPage - page) + state.currentPageOffsetFraction
        val f = feats[page]
        Column(
            Modifier.fillMaxSize()
                .graphicsLayer {
                    rotationY = (offset * 35f).coerceIn(-45f, 45f)
                    cameraDistance = 14f * density
                    val s = 1f - (abs(offset) * 0.12f).coerceIn(0f, 0.25f)
                    scaleX = s
                    scaleY = s
                    alpha = 1f - (abs(offset) * 0.4f).coerceIn(0f, 0.6f)
                }
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(f.c1, f.c2)))
                .padding(18.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x33FFFFFF)),
                contentAlignment = Alignment.Center) {
                Icon(f.icon, contentDescription = null, tint = Color.White)
            }
            Spacer(Modifier.height(10.dp))
            Text(f.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(4.dp))
            Text(f.text, fontSize = 14.sp, color = Color.White)
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.Center) {
        feats.indices.forEach { i ->
            Box(Modifier.padding(horizontal = 3.dp).size(if (i == state.currentPage) 16.dp else 6.dp, 6.dp)
                .clip(CircleShape).background(if (i == state.currentPage) Color(0xFFB7A6FF) else Color(0xFF34365C)))
        }
    }
}

@Composable
fun HomeScreen(
    onImage: () -> Unit = {}, onVideo: () -> Unit = {}, onProject: () -> Unit = {},
    onSuggestion: (String) -> Unit = {}
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var ask by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val mic = rememberVoiceInput { t -> ask = t }

    fun send() {
        val q = ask.trim()
        if (q.isEmpty() || busy) return
        busy = true
        answer = ""
        scope.launch {
            try {
                answer = withContext(Dispatchers.IO) { geminiAsk(Store.geminiKey(ctx), q) }
            } catch (e: GeminiException) {
                answer = e.message ?: "Gemini error."
            } catch (e: Exception) {
                answer = "Could not reach Gemini. Check your internet and try again."
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LogoMark(40.dp)
                Spacer(Modifier.width(10.dp))
                Text("Creative Studio", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Welcome, [Name]", fontSize = 13.sp, color = Muted)
                Text("Plan: Free · v$APP_VERSION", fontSize = 13.sp, color = Muted)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("ABOUT APP", fontSize = 13.sp, color = Muted, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(8.dp))
        FeatureCarousel()
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FeatureCard(Modifier.weight(1f), "Create Project", "60 s video", Icons.Filled.Add,
                Color(0xFF4B5BD6), Color(0xFF7A3EC8), onProject)
            FeatureCard(Modifier.weight(1f), "Generate Image", "Free", Icons.Filled.Image,
                Color(0xFF3F6AD8), Color(0xFF7040C0), onImage)
            FeatureCard(Modifier.weight(1f), "Generate Video", "8 s clip", Icons.Filled.Videocam,
                Color(0xFF5A4BD6), Color(0xFF9036B8), onVideo)
        }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = ask, onValueChange = { ask = it },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            singleLine = true,
            placeholder = { Text("Ask Gemini anything") },
            trailingIcon = {
                Row {
                    IconButton(onClick = mic) { Icon(Icons.Filled.Mic, contentDescription = "Speak", tint = Muted) }
                    IconButton(onClick = { send() }) { Icon(Icons.Filled.Send, contentDescription = "Send") }
                }
            }
        )
        if (busy) {
            Spacer(Modifier.height(12.dp))
            CircularProgressIndicator()
        }
        if (answer.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            InfoCard { T(answer, 14) }
        }
        Spacer(Modifier.height(18.dp))
        Text("Video suggestions", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(
                Triple("Epic Drone Journey", 0xFF2F5F7A, "A cinematic drone journey over mountains, rivers and forests at sunrise"),
                Triple("Korea Photobook", 0xFF5B2A63, "A travel photobook of Seoul with palaces, street food and cherry blossoms"),
                Triple("Sci-Fi Escape", 0xFF12103A, "A sci-fi hero escapes a space station while alarms flash"),
                Triple("Magical Forest", 0xFF0E2E2B, "A magical glowing forest with friendly creatures and floating lights")
            ).forEach { (name, c, prompt) ->
                Column(Modifier.width(112.dp).clickable { onSuggestion(prompt) }) {
                    Box(Modifier.fillMaxWidth().height(78.dp).clip(RoundedCornerShape(14.dp)).background(Color(c)),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color(0xCCFFFFFF))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(name, fontSize = 13.sp, color = Color(0xFFC9CCE6))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun FeatureCard(
    modifier: Modifier, title: String, sub: String, icon: ImageVector,
    c1: Color, c2: Color, onClick: () -> Unit = {}
) {
    Column(
        modifier.height(150.dp).clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(c1, c2))).clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x33FFFFFF)),
            contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = Color.White)
        }
        Spacer(Modifier.height(6.dp))
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center)
        Text(sub, fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center)
    }
}
