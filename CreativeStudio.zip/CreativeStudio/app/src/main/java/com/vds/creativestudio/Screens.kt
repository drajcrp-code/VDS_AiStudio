package com.vds.creativestudio

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlinx.coroutines.delay

private class Feat(val title: String, val clip: Int)
private class Sug(val title: String, val prompt: String, val clip: Int)

// Swipeable 3D carousel of short video clips that show what the app does.
@Composable
fun FeatureCarousel() {
    val feats = remember {
        listOf(
            Feat("Generate images", R.raw.about_image),
            Feat("Generate video clips", R.raw.about_video),
            Feat("Create 60 second projects", R.raw.about_project),
            Feat("Avatars and voices", R.raw.about_avatars),
            Feat("Your AI assistant", R.raw.about_assistant)
        )
    }
    val state = rememberPagerState(pageCount = { feats.size })
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            state.animateScrollToPage((state.currentPage + 1) % feats.size)
        }
    }
    HorizontalPager(
        state = state,
        contentPadding = PaddingValues(horizontal = 36.dp),
        pageSpacing = 4.dp,
        modifier = Modifier.fillMaxWidth().height(190.dp)
    ) { page ->
        val offset = (state.currentPage - page) + state.currentPageOffsetFraction
        val f = feats[page]
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer {
                    rotationY = (offset * 35f).coerceIn(-45f, 45f)
                    cameraDistance = 14f * density
                    val s = 1f - (abs(offset) * 0.12f).coerceIn(0f, 0.25f)
                    scaleX = s
                    scaleY = s
                    alpha = 1f - (abs(offset) * 0.4f).coerceIn(0f, 0.6f)
                }
                .clip(RoundedCornerShape(24.dp))
                .background(CardBg)
        ) {
            LoopingVideo(modifier = Modifier.fillMaxSize(), rawRes = f.clip)
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(0.55f to Color.Transparent, 1f to Color(0xCC0F1020))
                )
            )
            Text(f.title, Modifier.align(Alignment.BottomStart).padding(16.dp),
                fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.Center) {
        feats.indices.forEach { i ->
            Box(Modifier.padding(horizontal = 3.dp).size(if (i == state.currentPage) 16.dp else 6.dp, 6.dp)
                .clip(CircleShape).background(if (i == state.currentPage) Color(0xFFB7A6FF) else Color(0xFF34365C)))
        }
    }
}

@Composable
fun HomeScreen(
    onImage: () -> Unit = {}, onVideo: () -> Unit = {}, onProject: () -> Unit = {},
    onSuggestion: (String) -> Unit = {}
) {
    val suggestions = remember {
        listOf(
            Sug("Epic Drone Journey", "A cinematic drone journey over mountains, rivers and forests at sunrise", R.raw.sug_drone),
            Sug("Korea Photobook", "A travel photobook of Seoul with palaces, street food and cherry blossoms", R.raw.sug_korea),
            Sug("Sci-Fi Escape", "A sci-fi hero escapes a space station while alarms flash", R.raw.sug_scifi),
            Sug("Magical Forest", "A magical glowing forest with friendly creatures and floating lights", R.raw.sug_forest)
        )
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LogoMark(42.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("VDSAistudio", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Creative AI Studio", fontSize = 13.sp, color = Muted)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Plan: Free", fontSize = 13.sp, color = Muted)
                Text("v$APP_VERSION", fontSize = 13.sp, color = Muted)
            }
        }
        Spacer(Modifier.height(20.dp))
        FeatureCarousel()
        Spacer(Modifier.height(22.dp))
        Text("Create", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FeatureCard(Modifier.weight(1f), "Project", "60 s video", Icons.Filled.Add,
                Color(0xFF4B5BD6), Color(0xFF7A3EC8), onProject)
            FeatureCard(Modifier.weight(1f), "Image", "Free daily", Icons.Filled.Image,
                Color(0xFF3F6AD8), Color(0xFF7040C0), onImage)
            FeatureCard(Modifier.weight(1f), "Video", "Short clip", Icons.Filled.Videocam,
                Color(0xFF5A4BD6), Color(0xFF9036B8), onVideo)
        }
        Spacer(Modifier.height(22.dp))
        Text("Video ideas", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(suggestions) { s ->
                Column(Modifier.width(140.dp).clickable { onSuggestion(s.prompt) }) {
                    LoopingVideo(
                        modifier = Modifier.fillMaxWidth().height(98.dp).clip(RoundedCornerShape(14.dp)),
                        rawRes = s.clip
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(s.title, fontSize = 13.sp, color = Color(0xFFC9CCE6), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        BannerAd()
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun FeatureCard(
    modifier: Modifier, title: String, sub: String, icon: ImageVector,
    c1: Color, c2: Color, onClick: () -> Unit = {}
) {
    Column(
        modifier.height(118.dp).clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(c1, c2))).clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x33FFFFFF)),
            contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = Color.White)
        }
        Spacer(Modifier.height(8.dp))
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White,
            textAlign = TextAlign.Center, maxLines = 1)
        Text(sub, fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center, maxLines = 1)
    }
}
