package com.vds.creativestudio

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PlaceholderScreen(title: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable
fun HomeScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF7A3EC8), Color(0xFF4B5BD6)))),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color.White)
                }
                Spacer(Modifier.width(10.dp))
                Text("Creative Studio", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Welcome, [Name]", fontSize = 13.sp, color = Muted)
                Text("Plan: Free", fontSize = 13.sp, color = Muted)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("ABOUT APP", fontSize = 13.sp, color = Muted, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF2B2460), Color(0xFF7A3EC8))))) {
            Text("Creative Studio: The Future of AI Video",
                Modifier.align(Alignment.BottomStart).padding(16.dp),
                fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FeatureCard(Modifier.weight(1f), "Create Project", "60 s video", Icons.Filled.Add,
                Color(0xFF4B5BD6), Color(0xFF7A3EC8))
            FeatureCard(Modifier.weight(1f), "Generate Image", "Free", Icons.Filled.Image,
                Color(0xFF3F6AD8), Color(0xFF7040C0))
            FeatureCard(Modifier.weight(1f), "Generate Video", "8 s clip", Icons.Filled.Videocam,
                Color(0xFF5A4BD6), Color(0xFF9036B8))
        }
        Spacer(Modifier.height(16.dp))
        var ask by remember { mutableStateOf("") }
        OutlinedTextField(
            value = ask, onValueChange = { ask = it },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            placeholder = { Text("Ask Gemini anything") },
            trailingIcon = { Icon(Icons.Filled.Send, contentDescription = "Send") }
        )
        Spacer(Modifier.height(18.dp))
        Text("Video suggestions", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(
                "Epic Drone Journey" to 0xFF2F5F7A, "Korea Photobook" to 0xFF5B2A63,
                "Sci-Fi Escape" to 0xFF12103A, "Magical Forest" to 0xFF0E2E2B
            ).forEach { (name, c) ->
                Column(Modifier.width(112.dp)) {
                    Box(Modifier.fillMaxWidth().height(78.dp).clip(RoundedCornerShape(14.dp)).background(Color(c)))
                    Spacer(Modifier.height(6.dp))
                    Text(name, fontSize = 13.sp, color = Color(0xFFC9CCE6))
                }
            }
        }
    }
}

@Composable
fun FeatureCard(modifier: Modifier, title: String, sub: String, icon: ImageVector, c1: Color, c2: Color) {
    Column(
        modifier.height(128.dp).clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(c1, c2))).padding(horizontal = 6.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x33FFFFFF)),
            contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = Color.White)
        }
        Spacer(Modifier.height(6.dp))
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center)
        Text(sub, fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center)
    }
}
