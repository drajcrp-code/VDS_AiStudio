package com.vds.creativestudio

import android.content.Context
import java.time.LocalDate

const val APP_VERSION = "0.4"
const val FREE_IMAGES = 10 // free images per user per day (change here)
const val FREE_CLIPS = 2 // free short video clips per user per day (change here)

val STYLES = listOf("Warm", "Deep", "Bright", "Calm")
val DEFAULT_NAMES = listOf("Aria", "Max", "Zoe", "Kai")
val DEFAULT_STYLES = listOf("Warm", "Deep", "Bright", "Calm")

fun stylePitch(s: String): Float = when (s) {
    "Deep" -> 0.7f
    "Bright" -> 1.3f
    "Calm" -> 0.95f
    else -> 1.0f
}

fun styleSpeed(s: String): Float = when (s) {
    "Deep" -> 0.9f
    "Bright" -> 1.05f
    "Calm" -> 0.8f
    else -> 0.95f
}

class Avatar(val name: String, val style: String, val pitch: Float, val speed: Float)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("studio", Context.MODE_PRIVATE)

    fun owner(c: Context): Boolean = p(c).getBoolean("owner", false)
    fun setOwner(c: Context, v: Boolean) { p(c).edit().putBoolean("owner", v).apply() }

    fun used(c: Context, kind: String): Int {
        val today = LocalDate.now().toString()
        return if (p(c).getString("day_$kind", "") == today) p(c).getInt("n_$kind", 0) else 0
    }

    fun addUse(c: Context, kind: String) {
        val n = used(c, kind) + 1
        p(c).edit().putString("day_$kind", LocalDate.now().toString()).putInt("n_$kind", n).apply()
    }

    fun resetUse(c: Context) { p(c).edit().remove("n_image").remove("n_video").apply() }

    fun avatar(c: Context, i: Int): Avatar {
        val s = p(c).getString("av_style_$i", DEFAULT_STYLES[i]) ?: DEFAULT_STYLES[i]
        return Avatar(
            p(c).getString("av_name_$i", DEFAULT_NAMES[i]) ?: DEFAULT_NAMES[i],
            s,
            p(c).getFloat("av_pitch_$i", stylePitch(s)),
            p(c).getFloat("av_speed_$i", styleSpeed(s))
        )
    }

    fun saveAvatar(c: Context, i: Int, a: Avatar) {
        p(c).edit().putString("av_name_$i", a.name).putString("av_style_$i", a.style)
            .putFloat("av_pitch_$i", a.pitch).putFloat("av_speed_$i", a.speed).apply()
    }
}
