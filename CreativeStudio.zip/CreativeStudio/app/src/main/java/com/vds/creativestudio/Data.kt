package com.vds.creativestudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.time.LocalDate

const val APP_VERSION = "0.9"
// Google test ad unit. Replace with your own AdMob banner unit id before release.
const val AD_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
const val FREE_IMAGES = 10 // free images per user per day (change here)
const val FREE_CLIPS = 2 // free short video clips per user per day (change here)

val STYLES = listOf("Warm", "Deep", "Bright", "Calm")
val SEXES = listOf("Female", "Male", "Other")
val DEFAULT_NAMES = listOf("Aria", "Max", "Zoe", "Kai")
val DEFAULT_STYLES = listOf("Warm", "Deep", "Bright", "Calm")
val DEFAULT_SEX = listOf("Female", "Male", "Female", "Male")
val DEFAULT_AGE = listOf(28, 35, 24, 30)

fun stylePitch(s: String): Float = when (s) {
    "Deep" -> 0.7f
    "Bright" -> 1.3f
    "Calm" -> 0.95f
    else -> 1.0f
}

fun styleSpeed(s: String): Float = when (s) {
    "Deep" -> 0.9f
    "Bright" -> 1.05f
    "Calm" -> 0.8f
    else -> 0.95f
}

// Age and sex nudge the voice pitch. The user can still change it with the slider.
fun suggestPitch(style: String, sex: String, age: Int): Float {
    var p = stylePitch(style)
    if (sex == "Male") p *= 0.85f else if (sex == "Female") p *= 1.05f
    p *= when {
        age <= 8 -> 1.6f
        age < 13 -> 1.4f
        age < 18 -> 1.15f
        age > 60 -> 0.95f
        else -> 1.0f
    }
    return p.coerceIn(0.5f, 2.0f)
}

class Avatar(
    val name: String, val style: String, val pitch: Float, val speed: Float,
    val age: Int, val sex: String, val voice: String
)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("studio", Context.MODE_PRIVATE)

    fun owner(c: Context): Boolean = p(c).getBoolean("owner", false)
    fun setOwner(c: Context, v: Boolean) { p(c).edit().putBoolean("owner", v).apply() }

    fun geminiKey(c: Context): String = p(c).getString("gemini_key", "") ?: ""
    fun setGeminiKey(c: Context, v: String) { p(c).edit().putString("gemini_key", v).apply() }
    fun imageKey(c: Context): String = p(c).getString("image_key", "") ?: ""
    fun setImageKey(c: Context, v: String) { p(c).edit().putString("image_key", v).apply() }

    fun used(c: Context, kind: String): Int {
        val today = LocalDate.now().toString()
        return if (p(c).getString("day_$kind", "") == today) p(c).getInt("n_$kind", 0) else 0
    }

    fun addUse(c: Context, kind: String) {
        val n = used(c, kind) + 1
        p(c).edit().putString("day_$kind", LocalDate.now().toString()).putInt("n_$kind", n).apply()
    }

    fun resetUse(c: Context) { p(c).edit().remove("n_image").remove("n_video").apply() }

    fun avatar(c: Context, i: Int): Avatar {
        val s = p(c).getString("av_style_$i", DEFAULT_STYLES[i]) ?: DEFAULT_STYLES[i]
        val sex = p(c).getString("av_sex_$i", DEFAULT_SEX[i]) ?: DEFAULT_SEX[i]
        val age = p(c).getInt("av_age_$i", DEFAULT_AGE[i])
        return Avatar(
            p(c).getString("av_name_$i", DEFAULT_NAMES[i]) ?: DEFAULT_NAMES[i],
            s,
            p(c).getFloat("av_pitch_$i", suggestPitch(s, sex, age)),
            p(c).getFloat("av_speed_$i", styleSpeed(s)),
            age, sex,
            p(c).getString("av_voice_$i", "") ?: ""
        )
    }

    fun saveAvatar(c: Context, i: Int, a: Avatar) {
        p(c).edit().putString("av_name_$i", a.name).putString("av_style_$i", a.style)
            .putFloat("av_pitch_$i", a.pitch).putFloat("av_speed_$i", a.speed)
            .putInt("av_age_$i", a.age).putString("av_sex_$i", a.sex)
            .putString("av_voice_$i", a.voice).apply()
    }

    private fun avatarFile(c: Context, i: Int) = File(c.filesDir, "avatar_$i.jpg")

    fun avatarBitmap(c: Context, i: Int): Bitmap? {
        val f = avatarFile(c, i)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    fun saveAvatarImage(c: Context, i: Int, b: Bitmap) {
        val scale = minOf(1f, 512f / maxOf(b.width, b.height))
        val w = (b.width * scale).toInt().coerceAtLeast(1)
        val h = (b.height * scale).toInt().coerceAtLeast(1)
        val s = Bitmap.createScaledBitmap(b, w, h, true)
        avatarFile(c, i).outputStream().use { s.compress(Bitmap.CompressFormat.JPEG, 90, it) }
    }
}
