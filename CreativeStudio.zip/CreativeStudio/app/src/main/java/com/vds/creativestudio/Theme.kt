package com.vds.creativestudio

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0F1020)
val CardBg = Color(0xFF1B1D3A)
val Accent = Color(0xFF6D4AFF)
val Muted = Color(0xFFA9ACC6)

@Composable
fun StudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, background = Bg, surface = CardBg,
            onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}
