package com.vds.creativestudio

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private fun bodySnippet(c: HttpURLConnection): String = try {
    ((c.errorStream ?: c.inputStream)?.bufferedReader()?.use { it.readText() } ?: "")
        .take(160).replace('\n', ' ')
} catch (e: Exception) {
    ""
}

// Web address that asks the video service for one clip.
fun clipUrl(prompt: String, model: String, secs: Int, vertical: Boolean, key: String): String =
    "https://gen.pollinations.ai/video/" + Uri.encode(prompt.take(900)) +
        "?model=$model&duration=$secs&aspectRatio=" + (if (vertical) "9:16" else "16:9") +
        (if (model == "veo") "&audio=true" else "") +
        "&key=" + Uri.encode(key.trim())

// Downloads the finished clip into the app's cache and returns its file path.
fun downloadClip(ctx: Context, url: String, key: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 30000
    c.readTimeout = 420000
    c.setRequestProperty("User-Agent", "VDSAistudio")
    if (key.isNotBlank()) c.setRequestProperty("Authorization", "Bearer " + key.trim())
    try {
        val code = c.responseCode
        if (code == 401 || code == 403) throw KeyException()
        if (code == 402 || code == 429) throw BusyException()
        if (code >= 400) throw ClipException("The video service answered HTTP $code. ${bodySnippet(c)}")
        val type = c.contentType ?: ""
        if (!type.startsWith("video")) {
            val extra = if (type.startsWith("text") || type.contains("json")) bodySnippet(c) else ""
            throw ClipException("The video service sent \"$type\" instead of a video. $extra")
        }
        val f = File(ctx.cacheDir, "clip_${System.currentTimeMillis()}.mp4")
        c.inputStream.use { input -> f.outputStream().use { out -> input.copyTo(out) } }
        return f.path
    } finally {
        c.disconnect()
    }
}

// Reads single frames out of a clip, so they can be placed into the final video.
class ClipReader(path: String) {
    private val r = MediaMetadataRetriever()
    val durationUs: Long

    init {
        r.setDataSource(path)
        durationUs = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
    }

    fun frame(tUs: Long): Bitmap? = try {
        r.getFrameAtTime(tUs.coerceIn(0L, maxOf(0L, durationUs - 50_000L)), MediaMetadataRetriever.OPTION_CLOSEST)
    } catch (e: Exception) {
        null
    }

    fun close() {
        try { r.release() } catch (e: Exception) { }
    }
}
