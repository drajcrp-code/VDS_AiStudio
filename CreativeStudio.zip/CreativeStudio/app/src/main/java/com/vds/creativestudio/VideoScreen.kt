package com.vds.creativestudio

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

// Downloads the finished clip into the app's cache and returns its file path.
private fun downloadClip(ctx: Context, url: String, key: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 30000
    c.readTimeout = 420000
    c.setRequestProperty("User-Agent", "VDSAistudio")
    if (key.isNotBlank()) c.setRequestProperty("Authorization", "Bearer " + key.trim())
    try {
        val code = c.responseCode
        if (code == 401 || code == 403) throw KeyException()
        if (code == 402 || code == 429) throw BusyException()
        if (code >= 400) throw java.io.IOException("http $code")
        val type = c.contentType ?: ""
        if (!type.startsWith("video")) throw java.io.IOException("not a video")
        val f = File(ctx.cacheDir, "clip_${System.currentTimeMillis()}.mp4")
        c.inputStream.use { input -> f.outputStream().use { out -> input.copyTo(out) } }
        return f.path
    } finally {
        c.disconnect()
    }
}

private fun videoRefInstruction(prompt: String, secs: Int) =
    "The attached photo shows a person or character. Write ONE detailed prompt for a $secs second AI video clip that starts from this person " +
        "(keep face, hair, skin tone, age and clothes unless the user changes them) and does this: \"$prompt\". " +
        "Describe the action, camera movement and setting. Reply with the prompt only."

private fun videoEnhance(prompt: String, secs: Int) =
    "Rewrite this idea as ONE detailed prompt for a $secs second AI video clip. Keep every detail the user mentions. " +
        "Describe the action, camera movement and setting. Reply with the prompt only. Idea: $prompt"

@Composable
fun VideoScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val owner = Store.owner(ctx)
    var used by remember { mutableIntStateOf(Store.used(ctx, "video")) }
    val left = FREE_CLIPS - used
    var prompt by remember { mutableStateOf("") }
    var secs by remember { mutableIntStateOf(8) }
    var model by remember { mutableStateOf("seedance") }
    var wide by remember { mutableStateOf(true) }
    var ref by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var clipPath by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("Generate Video", onBack)
        Spacer(Modifier.height(12.dp))
        T(if (owner) "Owner mode: no limit" else "Free clips today: $left of $FREE_CLIPS left", 14, Muted)
        Spacer(Modifier.height(10.dp))
        PromptBox(prompt, { prompt = it }, "Describe your clip...")
        Spacer(Modifier.height(8.dp))
        AssistButton("video", prompt) { prompt = it }
        Spacer(Modifier.height(12.dp))
        ReferenceImage(ref, { ref = it }, { ref = null })
        Spacer(Modifier.height(12.dp))
        T("Model", 13, Muted)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip(selected = model == "seedance", onClick = { model = "seedance" }, label = { Text("Seedance") })
            Chip(selected = model == "veo", onClick = { model = "veo" }, label = { Text("Veo") })
        }
        Spacer(Modifier.height(12.dp))
        T("Format and length", 13, Muted)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip(selected = wide, onClick = { wide = true }, label = { Text("16:9") })
            Chip(selected = !wide, onClick = { wide = false }, label = { Text("9:16") })
            listOf(4, 6, 8).forEach { s ->
                Chip(selected = secs == s, onClick = { secs = s }, label = { Text("$s s") })
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                val ckey = Store.imageKey(ctx)
                if (prompt.isBlank() || loading) {
                    // nothing to do
                } else if (!owner && left <= 0) {
                    error = "Free limit reached for today."
                } else if (ckey.isBlank()) {
                    error = if (owner) "Add the images and video key in You > Settings first." else "Video clips are coming soon."
                } else {
                    loading = true
                    error = null
                    clipPath = null
                    val r = ref
                    scope.launch {
                        try {
                            val akey = Store.geminiKey(ctx)
                            val raw = if (r != null) {
                                withContext(Dispatchers.IO) { geminiAsk(akey, videoRefInstruction(prompt, secs), r) }
                            } else if (akey.isNotBlank()) {
                                try {
                                    withContext(Dispatchers.IO) { geminiAsk(akey, videoEnhance(prompt, secs)) }
                                } catch (e: Exception) {
                                    prompt
                                }
                            } else {
                                prompt
                            }
                            val full = raw.trim().trim('"')
                            val url = "https://gen.pollinations.ai/image/" + Uri.encode(full.take(900)) +
                                "?model=$model&duration=$secs&aspect_ratio=" + (if (wide) "16:9" else "9:16") +
                                "&key=" + Uri.encode(ckey.trim())
                            clipPath = withContext(Dispatchers.IO) { downloadClip(ctx, url, ckey) }
                            Store.addUse(ctx, "video")
                            used = Store.used(ctx, "video")
                        } catch (e: GeminiException) {
                            error = e.message ?: "Assistant error."
                        } catch (e: BusyException) {
                            error = "Your free video allowance is used up or the service is busy. Try again later."
                        } catch (e: KeyException) {
                            error = "The images and video key was not accepted. Check it in You > Settings."
                        } catch (e: Exception) {
                            error = "Could not create the clip. Check your internet and try again."
                        }
                        loading = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text(if (loading) "Creating clip..." else "Generate") }
        if (loading) {
            Spacer(Modifier.height(12.dp))
            T("This can take a few minutes. Please keep this screen open.", 14, Muted)
            Spacer(Modifier.height(8.dp))
            CircularProgressIndicator()
        }
        error?.let {
            Spacer(Modifier.height(12.dp))
            T(it, 14, Color(0xFFFF9A9A))
        }
        clipPath?.let { path ->
            Spacer(Modifier.height(16.dp))
            key(path) {
                LoopingVideo(
                    modifier = Modifier.fillMaxWidth(if (wide) 1f else 0.6f)
                        .aspectRatio(if (wide) 16f / 9f else 9f / 16f)
                        .align(Alignment.CenterHorizontally)
                        .clip(RoundedCornerShape(16.dp)),
                    path = path, muted = false
                )
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = {
                    val ok = saveVideoToGallery(ctx, path)
                    Toast.makeText(ctx, if (ok) "Saved to Movies/VDSAistudio" else "Saving needs Android 10 or newer.", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save to phone") }
        }
        Spacer(Modifier.height(16.dp))
    }
}
