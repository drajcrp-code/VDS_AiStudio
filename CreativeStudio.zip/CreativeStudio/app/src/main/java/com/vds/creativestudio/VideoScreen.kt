package com.vds.creativestudio

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private fun videoRefInstruction(prompt: String, secs: Int) =
    "The attached photo shows a person or character. Write ONE detailed prompt for a $secs second AI video clip that starts from this person " +
        "(keep face, hair, skin tone, age and clothes unless the user changes them) and does this: \"$prompt\". " +
        "Describe the action, camera movement and setting. Reply with the prompt only."

private fun videoEnhance(prompt: String, secs: Int) =
    "Rewrite this idea as ONE detailed prompt for a $secs second AI video clip. Keep every detail the user mentions. " +
        "Describe the action, camera movement and setting. Reply with the prompt only. Idea: $prompt"

@Composable
fun VideoScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val owner = Store.owner(ctx)
    val focus = LocalFocusManager.current
    var used by remember { mutableIntStateOf(Store.used(ctx, "video")) }
    val left = FREE_CLIPS - used
    var prompt by remember { mutableStateOf("") }
    var secs by remember { mutableIntStateOf(6) }
    var model by remember { mutableStateOf("seedance") }
    var wide by remember { mutableStateOf(true) }
    var ref by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var note by remember { mutableStateOf("") }
    var clipPath by remember { mutableStateOf<String?>(null) }

    fun generate() {
        val ckey = Store.imageKey(ctx)
        if (prompt.isBlank() || loading) return
        if (!owner && left <= 0) {
            error = "Free limit reached for today."
            return
        }
        if (ckey.isBlank()) {
            error = if (owner) "Add the images and video key in You > Settings first." else "Video clips are coming soon."
            return
        }
        focus.clearFocus()
        loading = true
        error = null
        note = ""
        clipPath = null
        val r = ref
        scope.launch {
            try {
                val akey = Store.geminiKey(ctx)
                val raw = if (r != null) {
                    try {
                        withContext(Dispatchers.IO) { geminiAsk(akey, videoRefInstruction(prompt, secs), r) }
                    } catch (e: GeminiBusyException) {
                        note = (e.message ?: "The assistant was busy.") + " Your photo was not used this time."
                        prompt
                    }
                } else if (akey.isNotBlank()) {
                    try {
                        withContext(Dispatchers.IO) { geminiAsk(akey, videoEnhance(prompt, secs)) }
                    } catch (e: Exception) {
                        prompt
                    }
                } else {
                    prompt
                }
                val full = raw.trim().trim('"')
                val url = "https://gen.pollinations.ai/video/" + Uri.encode(full.take(900)) +
                    "?model=$model&duration=$secs&aspectRatio=" + (if (wide) "16:9" else "9:16") +
                    (if (model == "veo") "&audio=true" else "") +
                    "&key=" + Uri.encode(ckey.trim())
                val file = withContext(Dispatchers.IO) { downloadClip(ctx, url, ckey) }
                clipPath = file
                try { Library.saveClip(ctx, file, full) } catch (e: Exception) { }
                Store.addUse(ctx, "video")
                used = Store.used(ctx, "video")
            } catch (e: GeminiException) {
                error = e.message ?: "Assistant error."
            } catch (e: BusyException) {
                error = "Your free video allowance is used up or the service is busy. Try again later."
            } catch (e: KeyException) {
                error = "The images and video key was not accepted. Check it in You > Settings."
            } catch (e: ClipException) {
                error = e.message ?: "The video service could not make the clip."
            } catch (e: Exception) {
                error = "Could not reach the video service. Check your internet and try again."
            }
            loading = false
        }
    }

    ToolScreen(
        title = "Generate Video", onBack = onBack,
        actionText = if (loading) "Creating clip..." else "Generate",
        busy = loading, onAction = { generate() }
    ) {
        T(if (owner) "Owner mode: no limit" else "Free clips today: $left of $FREE_CLIPS left", 14, Muted)
        Spacer(Modifier.height(12.dp))
        Section("YOUR IDEA") {
            PromptBox(prompt, { prompt = it }, "Describe your clip...", 120)
            Spacer(Modifier.height(8.dp))
            AssistButton("video", prompt) { prompt = it }
        }
        Spacer(Modifier.height(12.dp))
        Section("START FROM A PHOTO (OPTIONAL)") {
            ReferenceImage(ref, { ref = it }, { ref = null })
            Spacer(Modifier.height(8.dp))
            T("The assistant describes your photo, and the clip is made from that description.", 13, Muted)
        }
        Spacer(Modifier.height(12.dp))
        Section("SETTINGS") {
            T("Model", 13, Color.White)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(selected = model == "seedance", onClick = { model = "seedance" }, label = { Text("Seedance") })
                Chip(selected = model == "veo", onClick = { model = "veo" }, label = { Text("Veo") })
            }
            Spacer(Modifier.height(12.dp))
            T("Format", 13, Color.White)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(selected = wide, onClick = { wide = true }, label = { Text("16:9") })
                Chip(selected = !wide, onClick = { wide = false }, label = { Text("9:16") })
            }
            Spacer(Modifier.height(12.dp))
            T("Length", 13, Color.White)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(4, 6, 8).forEach { s ->
                    Chip(selected = secs == s, onClick = { secs = s }, label = { Text("$s s") })
                }
            }
        }
        if (loading) {
            Spacer(Modifier.height(16.dp))
            T("This can take a few minutes. Please keep this screen open.", 14, Muted)
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        }
        error?.let {
            Spacer(Modifier.height(12.dp))
            T(it, 14, Color(0xFFFF9A9A))
        }
        if (note.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            T(note, 14, Color(0xFFF5C76B))
        }
        clipPath?.let { path ->
            Spacer(Modifier.height(12.dp))
            Section("RESULT") {
                key(path) {
                    LoopingVideo(
                        modifier = Modifier.fillMaxWidth(if (wide) 1f else 0.6f)
                            .aspectRatio(if (wide) 16f / 9f else 9f / 16f)
                            .align(Alignment.CenterHorizontally)
                            .clip(RoundedCornerShape(14.dp)),
                        path = path, muted = false
                    )
                }
                Spacer(Modifier.height(10.dp))
                T("Saved in Projects", 13, Muted)
                Spacer(Modifier.height(6.dp))
                OutlinedButton(
                    onClick = {
                        val ok = saveVideoToGallery(ctx, path)
                        Toast.makeText(ctx, if (ok) "Saved to Movies/VDSAistudio" else "Saving needs Android 10 or newer.", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Save to phone") }
            }
        }
    }
}
