package com.vds.creativestudio

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun T(text: String, size: Int = 15, color: Color = Color.White, bold: Boolean = false) {
    Text(text, fontSize = size.sp, color = color,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
}

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        T(title, 20, bold = true)
    }
}

@Composable
fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardBg).padding(16.dp),
        content = content
    )
}

@Composable
fun Chip(selected: Boolean, onClick: () -> Unit, label: @Composable () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick, label = label,
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Accent, selectedLabelColor = Color.White
        )
    )
}

// Opens the phone's speech recognition. The spoken words come back through onText.
@Composable
fun rememberVoiceInput(onText: (String) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && text != null) onText(text)
    }
    return {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            launcher.launch(i)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Voice input is not available on this phone.", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun PromptBox(value: String, onChange: (String) -> Unit, hint: String, height: Int = 110) {
    val mic = rememberVoiceInput { t -> onChange(if (value.isBlank()) t else "$value $t") }
    OutlinedTextField(
        value = value, onValueChange = onChange,
        modifier = Modifier.fillMaxWidth().height(height.dp),
        shape = RoundedCornerShape(16.dp),
        placeholder = { Text(hint) },
        trailingIcon = {
            IconButton(onClick = mic) {
                Icon(Icons.Filled.Mic, contentDescription = "Speak", tint = Muted)
            }
        }
    )
}

fun loadScaledBitmap(ctx: Context, uri: Uri, max: Int): Bitmap? {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > max * 2 || bounds.outHeight / sample > max * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    } catch (e: Exception) {
        null
    }
}

@Composable
fun rememberImagePicker(onPicked: (Bitmap) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val b = loadScaledBitmap(ctx, uri, 1024)
            if (b != null) onPicked(b)
        }
    }
    return { launcher.launch("image/*") }
}

@Composable
fun ReferenceImage(bitmap: Bitmap?, onPick: (Bitmap) -> Unit, onClear: () -> Unit) {
    val pick = rememberImagePicker(onPick)
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(), contentDescription = "Reference image",
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.width(12.dp))
            OutlinedButton(onClick = onClear) { Text("Remove") }
        } else {
            OutlinedButton(onClick = pick) {
                Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Add reference image")
            }
        }
    }
}

// A titled card that groups one part of a form.
@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    InfoCard {
        T(title, 13, Muted)
        Spacer(Modifier.height(10.dp))
        content()
    }
}

// Standard layout for the tools: scrolling content with the main button fixed at the bottom.
@Composable
fun ToolScreen(
    title: String, onBack: () -> Unit, actionText: String, busy: Boolean, onAction: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            ScreenHeader(title, onBack)
            Spacer(Modifier.height(8.dp))
            content()
            Spacer(Modifier.height(16.dp))
        }
        Box(Modifier.fillMaxWidth().background(Bg).padding(horizontal = 20.dp, vertical = 12.dp)) {
            Button(
                onClick = onAction, enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text(actionText, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    }
}
