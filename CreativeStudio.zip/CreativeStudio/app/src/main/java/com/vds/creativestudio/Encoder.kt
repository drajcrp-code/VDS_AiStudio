package com.vds.creativestudio

import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

// Turns a series of pictures into an H.264 video (no sound).
class VideoWriter(file: File, private val w: Int, private val h: Int, private val fps: Int) {
    private val codec: MediaCodec = MediaCodec.createEncoderByType("video/avc")
    private val muxer: MediaMuxer = MediaMuxer(file.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var muxerStarted = false
    private var frames = 0L
    private var released = false

    init {
        val f = MediaFormat.createVideoFormat("video/avc", w, h)
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
        f.setInteger(MediaFormat.KEY_BIT_RATE, 3_000_000)
        f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
    }

    private fun drain(end: Boolean) {
        var idle = 0
        while (true) {
            val o = codec.dequeueOutputBuffer(info, if (end) 10_000 else 0)
            if (o == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!end) return
                idle++
                if (idle > 1000) throw IllegalStateException("The video encoder stopped answering.")
            } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = muxer.addTrack(codec.outputFormat)
                muxer.start()
                muxerStarted = true
            } else if (o >= 0) {
                val buf = codec.getOutputBuffer(o)!!
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                if (info.size > 0 && muxerStarted) {
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    muxer.writeSampleData(track, buf, info)
                }
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
            }
        }
    }

    private fun fill(img: Image, argb: IntArray) {
        val planes = img.planes
        val yBuf = planes[0].buffer
        val uBuf = planes[1].buffer
        val vBuf = planes[2].buffer
        val yStride = planes[0].rowStride
        val uStride = planes[1].rowStride
        val uPix = planes[1].pixelStride
        val vStride = planes[2].rowStride
        val vPix = planes[2].pixelStride
        for (row in 0 until h) {
            val base = row * w
            val yBase = row * yStride
            val evenRow = (row and 1) == 0
            for (col in 0 until w) {
                val c = argb[base + col]
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val b = c and 255
                yBuf.put(yBase + col, (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte())
                if (evenRow && (col and 1) == 0) {
                    val cr = row shr 1
                    val cc = col shr 1
                    uBuf.put(cr * uStride + cc * uPix, (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).toByte())
                    vBuf.put(cr * vStride + cc * vPix, (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).toByte())
                }
            }
        }
    }

    fun addFrame(argb: IntArray) {
        var idx = codec.dequeueInputBuffer(10_000)
        var spins = 0
        while (idx < 0) {
            drain(false)
            idx = codec.dequeueInputBuffer(10_000)
            spins++
            if (spins > 1000) throw IllegalStateException("The video encoder is not taking frames.")
        }
        val img = codec.getInputImage(idx) ?: throw IllegalStateException("The video encoder has no input.")
        fill(img, argb)
        codec.queueInputBuffer(idx, 0, w * h * 3 / 2, frames * 1_000_000L / fps, 0)
        frames++
        drain(false)
    }

    fun finish() {
        var idx = codec.dequeueInputBuffer(10_000)
        var spins = 0
        while (idx < 0) {
            drain(false)
            idx = codec.dequeueInputBuffer(10_000)
            spins++
            if (spins > 1000) throw IllegalStateException("The video encoder did not finish.")
        }
        codec.queueInputBuffer(idx, 0, 0, frames * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        drain(true)
        release()
    }

    fun release() {
        if (released) return
        released = true
        try { codec.stop() } catch (e: Exception) { }
        try { codec.release() } catch (e: Exception) { }
        try { if (muxerStarted) muxer.stop() } catch (e: Exception) { }
        try { muxer.release() } catch (e: Exception) { }
    }
}

// Turns 16-bit mono PCM sound into an AAC audio file.
fun encodeAac(pcm: ByteArray, rate: Int, out: File) {
    val fmt = MediaFormat.createAudioFormat("audio/mp4a-latm", rate, 1)
    fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
    fmt.setInteger(MediaFormat.KEY_BIT_RATE, 64_000)
    fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
    val codec = MediaCodec.createEncoderByType("audio/mp4a-latm")
    val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    var track = -1
    var started = false
    try {
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
        val info = MediaCodec.BufferInfo()
        var offset = 0
        var eosSent = false
        var done = false
        var guard = 0
        while (!done) {
            if (!eosSent) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val buf = codec.getInputBuffer(i)!!
                    buf.clear()
                    val n = minOf(buf.remaining(), pcm.size - offset) and -2
                    val pts = (offset / 2L) * 1_000_000L / rate
                    if (n <= 0) {
                        codec.queueInputBuffer(i, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        eosSent = true
                    } else {
                        buf.put(pcm, offset, n)
                        codec.queueInputBuffer(i, 0, n, pts, 0)
                        offset += n
                    }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10_000)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = muxer.addTrack(codec.outputFormat)
                muxer.start()
                started = true
            } else if (o >= 0) {
                val buf = codec.getOutputBuffer(o)!!
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                if (info.size > 0 && started) {
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    muxer.writeSampleData(track, buf, info)
                }
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) done = true
            } else if (o == MediaCodec.INFO_TRY_AGAIN_LATER && eosSent) {
                guard++
                if (guard > 1000) throw IllegalStateException("The audio encoder did not finish.")
            }
        }
    } finally {
        try { codec.stop() } catch (e: Exception) { }
        try { codec.release() } catch (e: Exception) { }
        try { if (started) muxer.stop() } catch (e: Exception) { }
        try { muxer.release() } catch (e: Exception) { }
    }
}

// Joins the silent video and the audio file into the final MP4.
fun muxFinal(videoFile: File, audioFile: File, out: File) {
    val ve = MediaExtractor()
    val ae = MediaExtractor()
    var mux: MediaMuxer? = null
    var started = false
    try {
        ve.setDataSource(videoFile.path)
        ae.setDataSource(audioFile.path)
        val vi = (0 until ve.trackCount).first { ve.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("video/") }
        val ai = (0 until ae.trackCount).first { ae.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
        ve.selectTrack(vi)
        ae.selectTrack(ai)
        val m = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        mux = m
        val vt = m.addTrack(ve.getTrackFormat(vi))
        val at = m.addTrack(ae.getTrackFormat(ai))
        m.start()
        started = true
        val buf = ByteBuffer.allocate(1 shl 20)
        val info = MediaCodec.BufferInfo()
        fun copy(ex: MediaExtractor, t: Int): Boolean {
            buf.clear()
            val n = ex.readSampleData(buf, 0)
            if (n < 0) return false
            info.set(0, n, ex.sampleTime, ex.sampleFlags)
            m.writeSampleData(t, buf, info)
            ex.advance()
            return true
        }
        var vDone = false
        var aDone = false
        while (!vDone || !aDone) {
            val vTime = if (vDone) Long.MAX_VALUE else ve.sampleTime
            val aTime = if (aDone) Long.MAX_VALUE else ae.sampleTime
            if (!vDone && vTime < 0) vDone = true
            if (!aDone && aTime < 0) aDone = true
            if (vDone && aDone) break
            if (!vDone && (aDone || vTime <= aTime)) {
                if (!copy(ve, vt)) vDone = true
            } else if (!aDone) {
                if (!copy(ae, at)) aDone = true
            }
        }
    } finally {
        try { if (started) mux?.stop() } catch (e: Exception) { }
        try { mux?.release() } catch (e: Exception) { }
        ve.release()
        ae.release()
    }
}
