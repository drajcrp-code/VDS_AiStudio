package com.vds.creativestudio

import android.content.Context
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Turns **bold** and "* " bullets into clean text.
fun md(text: String): AnnotatedString = buildAnnotatedString {
    text.lines().forEachIndexed { li, raw ->
        if (li > 0) append("\n")
        var line = raw.trimEnd()
        if (line.startsWith("* ") || line.startsWith("- ")) line = "• " + line.substring(2)
        line = line.trimStart('#', ' ')
        var i = 0
        var bold = false
        while (i < line.length) {
            if (line.startsWith("**", i)) {
                bold = !bold
                i += 2
            } else {
                if (bold) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(line[i]) }
                } else {
                    append(line[i])
                }
                i++
            }
        }
    }
}

private fun wrap(mode: String, q: String): String = when (mode) {
    "Story" -> "Write a short, simple story (about 150 words) for a 60 second narrated video about: $q. Use short clear sentences. Reply with the story only."
    "Image prompt" -> "Write one detailed image generation prompt (subject, setting, lighting, style, camera angle) for: $q. Do not mention aspect ratio, resolution, text overlays or watermarks. Reply with the prompt only, in one paragraph."
    "Video prompt" -> "Write one detailed prompt for an 8 second AI video clip (subject, action, camera movement, setting, mood) for: $q. Reply with the prompt only."
    else -> q
}

private val LIVE_WORDS = Regex("\\b(today|tonight|latest|news|score|scores|live|price|weather|current|currently|now|yesterday|tomorrow|result|results|202\\d)\\b", RegexOption.IGNORE_CASE)

// Holds the assistant chat, so the answer stays when you switch tabs.
class AssistantState {
    var mode by mutableStateOf("Ask")
    var input by mutableStateOf("")
    var answer by mutableStateOf("")
    var busy by mutableStateOf(false)

    fun run(ctx: Context, scope: CoroutineScope) {
        val q = input.trim()
        if (q.isEmpty() || busy) return
        busy = true
        answer = ""
        val m = mode
        val useLive = m == "Ask" && LIVE_WORDS.containsMatchIn(q)
        scope.launch {
            try {
                answer = withContext(Dispatchers.IO) { geminiAsk(Store.geminiKey(ctx), wrap(m, q), null, useLive) }
            } catch (e: GeminiException) {
                answer = e.message ?: "Assistant error."
            } catch (e: Exception) {
                answer = "Could not reach the assistant. Check your internet and try again."
            }
            busy = false
        }
    }
}

private fun assistInstruction(kind: String, p: String): String {
    val idea = p.trim()
    return when (kind) {
        "image" -> if (idea.isEmpty()) {
            "Invent one creative, vivid idea for an AI image and write it as ONE detailed image prompt. Reply with the prompt only."
        } else {
            "Rewrite this as ONE detailed prompt for an AI image generator. Keep every detail I mention and do not add new main subjects. Add helpful detail (lighting, camera, mood). Do not mention aspect ratio, resolution, text overlays or watermarks. Reply with the prompt only. Idea: $idea"
        }
        "video" -> if (idea.isEmpty()) {
            "Invent one creative idea for a short AI video clip and write it as ONE detailed prompt with action and camera movement. Reply with the prompt only."
        } else {
            "Rewrite this as ONE detailed prompt for a short AI video clip. Keep every detail I mention. Describe the action, camera movement and setting. Do not mention aspect ratio, resolution, text overlays or watermarks. Reply with the prompt only. Idea: $idea"
        }
        else -> if (idea.isEmpty()) {
            "Write a short, simple story script (about 150 words) for a 60 second narrated video on any fun topic. Reply with the script only."
        } else {
            "Write a short, simple story script (about 150 words) for a 60 second narrated video. Keep my idea. Use short clear sentences. Reply with the script only. Idea: $idea"
        }
    }
}

// A button that asks the assistant to write or improve the prompt above it.
@Composable
fun AssistButton(kind: String, prompt: String, onResult: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    Column {
        OutlinedButton(
            onClick = {
                if (!busy) {
                    busy = true
                    err = ""
                    scope.launch {
                        try {
                            val text = withContext(Dispatchers.IO) {
                                geminiAsk(Store.geminiKey(ctx), assistInstruction(kind, prompt))
                            }
                            onResult(text.trim().trim('"'))
                        } catch (e: GeminiException) {
                            err = e.message ?: "Assistant error."
                        } catch (e: Exception) {
                            err = "Could not reach the assistant. Check your internet."
                        }
                        busy = false
                    }
                }
            }
        ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(if (busy) "Writing..." else if (prompt.isBlank()) "Write a prompt for me" else "Improve with Assistant")
        }
        if (err.isNotEmpty()) T(err, 13, Color(0xFFFF9A9A))
    }
}

@Composable
fun AssistantScreen(
    state: AssistantState, scope: CoroutineScope, onBack: () -> Unit,
    onUseForImage: (String) -> Unit, onUseForProject: (String) -> Unit
) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("Assistant", onBack)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Ask", "Story", "Image prompt", "Video prompt").forEach { m ->
                Chip(selected = state.mode == m, onClick = { state.mode = m }, label = { Text(m) })
            }
        }
        Spacer(Modifier.height(12.dp))
        PromptBox(
            state.input, { state.input = it },
            when (state.mode) {
                "Story" -> "What should the story be about?"
                "Image prompt" -> "Describe your idea. I will write the image prompt."
                "Video prompt" -> "Describe your idea. I will write the video prompt."
                else -> "Ask anything..."
            }
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { state.run(ctx, scope) }, enabled = !state.busy,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text(if (state.busy) "Thinking..." else if (state.mode == "Ask") "Ask" else "Write") }
        if (state.busy) {
            Spacer(Modifier.height(12.dp))
            CircularProgressIndicator()
        }
        if (state.answer.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            InfoCard {
                SelectionContainer {
                    Text(md(state.answer), fontSize = 15.sp, lineHeight = 22.sp, color = Color.White)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { clip.setText(AnnotatedString(state.answer)) }, modifier = Modifier.weight(1f)) { Text("Copy") }
                OutlinedButton(onClick = { state.answer = "" }, modifier = Modifier.weight(1f)) { Text("Clear") }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onUseForImage(state.answer) }, modifier = Modifier.weight(1f)) { Text("Make image") }
                OutlinedButton(onClick = { onUseForProject(state.answer) }, modifier = Modifier.weight(1f)) { Text("Use in project") }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
