package com.vds.creativestudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import java.io.File

class Creation(val file: File, val isVideo: Boolean, val prompt: String, val time: Long)

// Everything you generate is saved inside the app and shown in the Projects tab.
object Library {
    private fun dir(c: Context): File = File(c.filesDir, "creations").apply { mkdirs() }

    fun saveImage(c: Context, bmp: Bitmap, prompt: String) {
        val t = System.currentTimeMillis()
        File(dir(c), "img_$t.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        File(dir(c), "img_$t.txt").writeText(prompt)
    }

    fun saveClip(c: Context, path: String, prompt: String) {
        val t = System.currentTimeMillis()
        File(path).copyTo(File(dir(c), "vid_$t.mp4"), overwrite = true)
        File(dir(c), "vid_$t.txt").writeText(prompt)
    }

    fun list(c: Context): List<Creation> =
        (dir(c).listFiles() ?: emptyArray())
            .filter { it.name.endsWith(".jpg") || it.name.endsWith(".mp4") }
            .map { f ->
                val txt = File(f.parentFile, f.nameWithoutExtension + ".txt")
                Creation(f, f.name.endsWith(".mp4"), if (txt.exists()) txt.readText() else "", f.lastModified())
            }
            .sortedByDescending { it.time }

    fun delete(item: Creation) {
        item.file.delete()
        File(item.file.parentFile, item.file.nameWithoutExtension + ".txt").delete()
    }

    fun thumb(item: Creation): Bitmap? = try {
        if (item.isVideo) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(item.file.path)
                r.getFrameAtTime(500_000)
            } finally {
                r.release()
            }
        } else {
            BitmapFactory.decodeFile(item.file.path, BitmapFactory.Options().apply { inSampleSize = 4 })
        }
    } catch (e: Exception) {
        null
    }
}
