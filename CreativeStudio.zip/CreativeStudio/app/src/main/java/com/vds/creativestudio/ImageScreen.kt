package com.vds.creativestudio

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private fun imageUrl(prompt: String, key: String): String {
    val seed = (0..999999).random()
    val p = Uri.encode(prompt.take(900))
    return if (key.isBlank()) {
        "https://image.pollinations.ai/prompt/$p?width=1024&height=1024&model=flux&nologo=true&seed=$seed"
    } else {
        "https://gen.pollinations.ai/image/$p?model=flux&width=1024&height=1024&nologo=true&seed=$seed&key=" + Uri.encode(key.trim())
    }
}

private fun open(url: String, key: String): HttpURLConnection {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 30000
    c.readTimeout = 120000
    c.setRequestProperty("User-Agent", "VDSAistudio")
    if (key.isNotBlank()) c.setRequestProperty("Authorization", "Bearer " + key.trim())
    return c
}

// Free image service. With a key it uses the newer endpoint, which should not add a logo.
private fun fetchOnce(prompt: String, key: String): Bitmap? {
    var c = open(imageUrl(prompt, key), key)
    var code = c.responseCode
    if (key.isNotBlank() && code in 400..499 && code != 401 && code != 403 && code != 402 && code != 429) {
        c.disconnect()
        c = open(imageUrl(prompt, ""), "")
        code = c.responseCode
    }
    return try {
        if (code == 402 || code == 429 || code >= 500) throw BusyException()
        if (code == 401 || code == 403) throw KeyException()
        c.inputStream.use { BitmapFactory.decodeStream(it) }
    } finally {
        c.disconnect()
    }
}

private suspend fun fetchImage(prompt: String, key: String): Bitmap {
    var busy = false
    for (attempt in 0..2) {
        try {
            val b = withContext(Dispatchers.IO) { fetchOnce(prompt, key) }
            if (b != null) return b
        } catch (e: BusyException) {
            busy = true
        } catch (e: java.io.IOException) {
            busy = false
        }
        if (attempt < 2) delay(5000L)
    }
    throw if (busy) BusyException() else java.io.IOException("network")
}

private fun refInstruction(prompt: String, style: String) =
    "The attached photo shows a person or character. The user wants this image: \"$prompt\". " +
        "Write ONE detailed prompt for an AI image generator that keeps the face, hair, skin tone, age and body of the person in the photo, " +
        "and applies exactly what the user asks (for example new clothes or a new place). Style: $style. " +
        "Describe only the final image. Reply with the prompt only."

private fun enhanceInstruction(prompt: String, style: String) =
    "Rewrite this idea as ONE detailed prompt for an AI image generator. Keep every detail the user mentions and do not add new main subjects. " +
        "Add helpful visual detail (lighting, camera, mood). Style: $style. Reply with the prompt only. Idea: $prompt"

@Composable
fun ImageScreen(initialPrompt: String = "", onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val owner = Store.owner(ctx)
    var prompt by remember { mutableStateOf(initialPrompt) }
    var style by remember { mutableStateOf("Realistic") }
    var used by remember { mutableIntStateOf(Store.used(ctx, "image")) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var usedPrompt by remember { mutableStateOf("") }
    var ref by remember { mutableStateOf<Bitmap?>(null) }
    val left = FREE_IMAGES - used

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("Generate Image", onBack)
        Spacer(Modifier.height(12.dp))
        Text(if (owner) "Owner mode: no limit" else "Free images today: $left of $FREE_IMAGES left",
            fontSize = 14.sp, color = Muted)
        Spacer(Modifier.height(10.dp))
        PromptBox(prompt, { prompt = it }, "Describe the image you want...")
        Spacer(Modifier.height(8.dp))
        AssistButton("image", prompt) { prompt = it }
        Spacer(Modifier.height(12.dp))
        ReferenceImage(ref, { ref = it }, { ref = null })
        if (ref != null) {
            Spacer(Modifier.height(6.dp))
            T("The assistant studies your photo and keeps the face and look. Say what to change, for example new clothes or a new place.", 13, Muted)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Realistic", "Anime", "Cinematic", "3D").forEach { s ->
                Chip(selected = style == s, onClick = { style = s }, label = { Text(s) })
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (prompt.isBlank() || loading) {
                    // nothing to do
                } else if (!owner && left <= 0) {
                    error = "Free limit reached for today."
                } else {
                    loading = true
                    error = null
                    result = null
                    val r = ref
                    scope.launch {
                        try {
                            val akey = Store.geminiKey(ctx)
                            val raw = if (r != null) {
                                withContext(Dispatchers.IO) { geminiAsk(akey, refInstruction(prompt, style), r) }
                            } else if (akey.isNotBlank()) {
                                try {
                                    withContext(Dispatchers.IO) { geminiAsk(akey, enhanceInstruction(prompt, style)) }
                                } catch (e: Exception) {
                                    "$prompt, $style style"
                                }
                            } else {
                                "$prompt, $style style"
                            }
                            val full = raw.trim().trim('"')
                            usedPrompt = full
                            result = fetchImage(full, Store.imageKey(ctx))
                            Store.addUse(ctx, "image")
                            used = Store.used(ctx, "image")
                        } catch (e: GeminiException) {
                            error = e.message ?: "Assistant error."
                        } catch (e: BusyException) {
                            error = "The image service is busy or your free allowance is used up. Wait a minute and try again."
                        } catch (e: KeyException) {
                            error = "The images key was not accepted. Check it in You > Settings."
                        } catch (e: Exception) {
                            error = "Network error. Check your internet and try again."
                        }
                        loading = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(if (loading) "Creating... (up to a minute)" else "Generate", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        if (loading) {
            Box(Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        error?.let { Text(it, color = Color(0xFFFF9A9A), fontSize = 14.sp) }
        result?.let { bmp ->
            Image(
                bitmap = bmp.asImageBitmap(), contentDescription = "Generated image",
                modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp))
            )
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = {
                    val ok = saveImageToGallery(ctx, bmp)
                    Toast.makeText(ctx, if (ok) "Saved to Pictures/VDSAistudio" else "Saving needs Android 10 or newer.", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save to phone") }
            if (usedPrompt.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                T("Prompt used", 13, Muted)
                SelectionContainer { T(usedPrompt, 13, Color(0xFFC9CCE6)) }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
