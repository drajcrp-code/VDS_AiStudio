package com.vds.creativestudio

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private class BusyException : Exception()
private class KeyException : Exception()

// Free image service. Swap this function later to use another provider.
private fun fetchOnce(prompt: String, key: String): Bitmap? {
    val url = "https://image.pollinations.ai/prompt/" + Uri.encode(prompt) +
        "?width=1024&height=1024&model=flux&nologo=true&seed=" + (0..999999).random()
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 30000
    c.readTimeout = 120000
    c.setRequestProperty("User-Agent", "CreativeStudio")
    if (key.isNotBlank()) c.setRequestProperty("Authorization", "Bearer " + key.trim())
    return try {
        val code = c.responseCode
        if (code == 429 || code >= 500) throw BusyException()
        if (code == 401 || code == 403) throw KeyException()
        c.inputStream.use { BitmapFactory.decodeStream(it) }
    } finally {
        c.disconnect()
    }
}

private suspend fun fetchImage(prompt: String, key: String): Bitmap {
    var busy = false
    for (attempt in 0..2) {
        try {
            val b = withContext(Dispatchers.IO) { fetchOnce(prompt, key) }
            if (b != null) return b
        } catch (e: BusyException) {
            busy = true
        } catch (e: java.io.IOException) {
            busy = false
        }
        if (attempt < 2) delay(5000L)
    }
    throw if (busy) BusyException() else java.io.IOException("network")
}

@Composable
fun ImageScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val owner = Store.owner(ctx)
    var prompt by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("Realistic") }
    var used by remember { mutableIntStateOf(Store.used(ctx, "image")) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    var ref by remember { mutableStateOf<Bitmap?>(null) }
    val left = FREE_IMAGES - used

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("Generate Image", onBack)
        Spacer(Modifier.height(12.dp))
        Text(if (owner) "Owner mode: no limit" else "Free images today: $left of $FREE_IMAGES left",
            fontSize = 14.sp, color = Muted)
        Spacer(Modifier.height(10.dp))
        PromptBox(prompt, { prompt = it }, "Describe the image you want...")
        Spacer(Modifier.height(12.dp))
        ReferenceImage(ref, { ref = it }, { ref = null })
        if (ref != null) {
            Spacer(Modifier.height(6.dp))
            T("Gemini reads your photo, then the image is created in that look. It is not an exact copy.", 13, Muted)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Realistic", "Anime", "Cinematic", "3D").forEach { s ->
                Chip(selected = style == s, onClick = { style = s }, label = { Text(s) })
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (prompt.isBlank() || loading) {
                    // nothing to do
                } else if (!owner && left <= 0) {
                    error = "Free limit reached for today."
                } else {
                    loading = true
                    error = null
                    image = null
                    val r = ref
                    scope.launch {
                        try {
                            var full = "$prompt, $style style"
                            if (r != null) {
                                val look = withContext(Dispatchers.IO) {
                                    geminiAsk(
                                        Store.geminiKey(ctx),
                                        "Describe this image in one detailed sentence (subject, colors, clothing, setting, mood) so an AI image generator can recreate its look. Reply with the sentence only.",
                                        r
                                    )
                                }
                                full = "$prompt, in the look of: $look, $style style"
                            }
                            val bmp = fetchImage(full, Store.imageKey(ctx))
                            image = bmp.asImageBitmap()
                            Store.addUse(ctx, "image")
                            used = Store.used(ctx, "image")
                        } catch (e: GeminiException) {
                            error = e.message ?: "Gemini error."
                        } catch (e: BusyException) {
                            error = "The free image service is busy. Wait a minute and try again."
                        } catch (e: KeyException) {
                            error = "The image service key was not accepted. Check it in Settings."
                        } catch (e: Exception) {
                            error = "Network error. Check your internet and try again."
                        }
                        loading = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(if (loading) "Creating... (up to a minute)" else "Generate", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        if (loading) {
            Box(Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        error?.let { Text(it, color = Color(0xFFFF9A9A), fontSize = 14.sp) }
        image?.let {
            Image(
                bitmap = it, contentDescription = "Generated image",
                modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp))
            )
            if (owner && Store.imageKey(ctx).isBlank()) {
                Spacer(Modifier.height(8.dp))
                T("The free service adds its logo. Add an image service key in Settings to try removing it.", 13, Muted)
            }
        }
    }
}
