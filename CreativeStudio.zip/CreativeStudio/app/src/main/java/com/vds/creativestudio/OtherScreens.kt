package com.vds.creativestudio

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val Warn = Color(0xFFF5C76B)

@Composable
fun ProjectsScreen(onCreate: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        T("Projects", 24, bold = true)
        Spacer(Modifier.weight(1f))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            T("No projects yet", 18, bold = true)
            Spacer(Modifier.height(6.dp))
            T("Your finished videos will appear here.", 14, Muted)
            Spacer(Modifier.height(16.dp))
            Button(onClick = onCreate) { Text("Create Project") }
        }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
fun AvatarsScreen(onEdit: (Int) -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        T("Avatars", 24, bold = true)
        T("Characters and voices for your projects", 14, Muted)
        Spacer(Modifier.height(16.dp))
        (0..3).forEach { i ->
            val a = Store.avatar(ctx, i)
            Row(
                Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp))
                    .background(CardBg).clickable { onEdit(i) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0xFF2B2460)),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Person, contentDescription = null, tint = Color(0xFFB7A6FF))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    T(a.name, 16, bold = true)
                    T("Voice: ${a.style}", 13, Muted)
                }
                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Muted)
            }
        }
    }
}

@Composable
fun EditAvatarScreen(index: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val start = remember { Store.avatar(ctx, index) }
    var name by remember { mutableStateOf(start.name) }
    var style by remember { mutableStateOf(start.style) }
    var pitch by remember { mutableFloatStateOf(start.pitch) }
    var speed by remember { mutableFloatStateOf(start.speed) }
    var ready by remember { mutableStateOf(false) }
    val tts = remember { arrayOfNulls<TextToSpeech>(1) }
    DisposableEffect(Unit) {
        tts[0] = TextToSpeech(ctx) { status -> ready = (status == TextToSpeech.SUCCESS) }
        onDispose {
            tts[0]?.stop()
            tts[0]?.shutdown()
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("Edit avatar", onBack)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = name, onValueChange = { name = it }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), label = { Text("Name") }
        )
        Spacer(Modifier.height(16.dp))
        T("Voice", 13, Muted)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            STYLES.forEach { s ->
                Chip(selected = style == s,
                    onClick = { style = s; pitch = stylePitch(s); speed = styleSpeed(s) },
                    label = { Text(s) })
            }
        }
        Spacer(Modifier.height(12.dp))
        T("Pitch", 13, Muted)
        Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.5f..1.5f)
        T("Speed", 13, Muted)
        Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.5f..1.5f)
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = {
                val t = tts[0]
                if (ready && t != null) {
                    t.setPitch(pitch)
                    t.setSpeechRate(speed)
                    t.speak("Hello, I am $name. This is how my voice sounds.", TextToSpeech.QUEUE_FLUSH, null, "preview")
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Preview voice") }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                Store.saveAvatar(ctx, index, Avatar(name.ifBlank { start.name }, style, pitch, speed))
                onBack()
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Save avatar") }
    }
}

@Composable
fun VideoScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val owner = Store.owner(ctx)
    val left = FREE_CLIPS - Store.used(ctx, "video")
    var prompt by remember { mutableStateOf("") }
    var secs by remember { mutableIntStateOf(8) }
    var note by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("Generate Video", onBack)
        Spacer(Modifier.height(12.dp))
        T(if (owner) "Owner mode: no limit" else "Free clips today: $left of $FREE_CLIPS left", 14, Muted)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = prompt, onValueChange = { prompt = it },
            modifier = Modifier.fillMaxWidth().height(110.dp),
            shape = RoundedCornerShape(16.dp),
            placeholder = { Text("Describe your clip...") }
        )
        Spacer(Modifier.height(12.dp))
        T("Length", 13, Muted)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(4, 6, 8).forEach { s ->
                Chip(selected = secs == s, onClick = { secs = s }, label = { Text("$s s") })
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { note = "Clip generation is not connected yet. It comes in the next stage." },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Generate") }
        if (note.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            T(note, 14, Warn)
        }
    }
}

@Composable
fun ProjectScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var sel by remember { mutableIntStateOf(0) }
    var prompt by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val av = Store.avatar(ctx, sel)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader("Create Project", onBack)
        Spacer(Modifier.height(12.dp))
        T("Character", 13, Muted)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (0..3).forEach { i ->
                Chip(selected = sel == i, onClick = { sel = i }, label = { Text(Store.avatar(ctx, i).name) })
            }
        }
        Spacer(Modifier.height(8.dp))
        T("Voice: ${av.style}", 14, Muted)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = prompt, onValueChange = { prompt = it },
            modifier = Modifier.fillMaxWidth().height(110.dp),
            shape = RoundedCornerShape(16.dp),
            placeholder = { Text("Describe your video in one prompt...") }
        )
        Spacer(Modifier.height(12.dp))
        T("Length: 60 s. Needs a subscription.", 14, Muted)
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { note = "60 second video creation is not connected yet. It comes in a later stage." },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Create video") }
        if (note.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            T(note, 14, Warn)
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        T("Settings", 24, bold = true)
        Spacer(Modifier.height(16.dp))
        InfoCard {
            T("App version", 13, Muted)
            T(APP_VERSION, 16, bold = true)
        }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(
            onClick = { Store.resetUse(ctx); msg = "Today's free counters were reset." },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Reset today's free counters") }
        if (msg.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            T(msg, 14, Muted)
        }
    }
}

@Composable
fun YouScreen() {
    val ctx = LocalContext.current
    var owner by remember { mutableStateOf(Store.owner(ctx)) }
    val imgLeft = FREE_IMAGES - Store.used(ctx, "image")
    val vidLeft = FREE_CLIPS - Store.used(ctx, "video")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        T("You", 24, bold = true)
        Spacer(Modifier.height(16.dp))
        InfoCard {
            T(if (owner) "Plan: Owner" else "Plan: Free", 18, bold = true)
            Spacer(Modifier.height(6.dp))
            T(if (owner) "No limits on this phone" else "Free images left today: $imgLeft of $FREE_IMAGES", 14, Muted)
            if (!owner) T("Free video clips left today: $vidLeft of $FREE_CLIPS", 14, Muted)
        }
        Spacer(Modifier.height(12.dp))
        InfoCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Owner mode", 16, bold = true)
                    T("For testing only. Removes all limits on this phone. Remove before public release.", 13, Muted)
                }
                Spacer(Modifier.width(12.dp))
                Switch(checked = owner, onCheckedChange = { owner = it; Store.setOwner(ctx, it) })
            }
        }
        Spacer(Modifier.height(12.dp))
        InfoCard {
            T("Credits and subscription", 16, bold = true)
            T("Coming in a later stage.", 14, Muted)
        }
    }
}
