package com.vds.creativestudio

import java.io.File

// 16-bit mono PCM audio (little endian).
class Pcm(val data: ByteArray, val sampleRate: Int)

// Reads the WAV file that the phone's text-to-speech wrote.
fun readWavPcm(f: File): Pcm? {
    val b = f.readBytes()
    if (b.size < 44) return null
    fun le16(o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
    fun le32(o: Int) = le16(o) or (le16(o + 2) shl 16)
    val channels = le16(22)
    val rate = le32(24)
    val bits = le16(34)
    if (bits != 16 || rate <= 0) return null
    var pos = 12
    var start = -1
    var len = 0
    while (pos + 8 <= b.size) {
        val id = String(b, pos, 4, Charsets.US_ASCII)
        val l = le32(pos + 4)
        if (id == "data") {
            start = pos + 8
            len = if (l <= 0 || start + l > b.size) b.size - start else l
            break
        }
        if (l < 0) break
        pos += 8 + l + (l and 1)
    }
    if (start < 0 || len <= 0) return null
    var pcm = b.copyOfRange(start, start + len)
    if (channels == 2) {
        val mono = ByteArray(pcm.size / 2)
        for (i in 0 until pcm.size / 4) {
            mono[2 * i] = pcm[4 * i]
            mono[2 * i + 1] = pcm[4 * i + 1]
        }
        pcm = mono
    }
    return Pcm(pcm, rate)
}

// Simple resampling, only used if two scenes came back with different sample rates.
fun resampleTo(p: Pcm, rate: Int): ByteArray {
    if (p.sampleRate == rate) return p.data
    val inSamples = p.data.size / 2
    val outSamples = (inSamples.toLong() * rate / p.sampleRate).toInt()
    val out = ByteArray(outSamples * 2)
    for (i in 0 until outSamples) {
        val src = (i.toLong() * p.sampleRate / rate).toInt().coerceAtMost(inSamples - 1)
        out[2 * i] = p.data[2 * src]
        out[2 * i + 1] = p.data[2 * src + 1]
    }
    return out
}
