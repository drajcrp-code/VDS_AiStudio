package com.vds.creativestudio

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class GeminiException(msg: String) : Exception(msg)

// Tried in order. If the first model is not found, the next one is used.
private val GEMINI_MODELS = listOf("gemini-2.5-flash", "gemini-3.5-flash")

private fun toBase64(b: Bitmap): String {
    val big = maxOf(b.width, b.height)
    val scale = minOf(1f, 1024f / big)
    val s = if (scale < 1f) Bitmap.createScaledBitmap(b, (b.width * scale).toInt(), (b.height * scale).toInt(), true) else b
    val out = ByteArrayOutputStream()
    s.compress(Bitmap.CompressFormat.JPEG, 80, out)
    return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
}

// Blocking call. Run it on a background thread (Dispatchers.IO).
fun geminiAsk(key: String, text: String, image: Bitmap? = null): String {
    if (key.isBlank()) throw GeminiException("Gemini is not set up yet. Owner: add the Gemini key in Settings.")
    val parts = JSONArray()
    if (image != null) {
        parts.put(JSONObject().put("inline_data",
            JSONObject().put("mime_type", "image/jpeg").put("data", toBase64(image))))
    }
    parts.put(JSONObject().put("text", text))
    val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts))).toString()
    for (m in GEMINI_MODELS) {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 30000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key.trim())
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val resp = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code in 200..299) {
                return JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                    .getString("text").trim()
            }
            when (code) {
                400, 401, 403 -> throw GeminiException("The Gemini key was not accepted. Check it in Settings.")
                429 -> throw GeminiException("Gemini free limit reached. Try again later.")
                404 -> { /* try the next model */ }
                else -> throw GeminiException("Gemini error $code.")
            }
        } finally {
            c.disconnect()
        }
    }
    throw GeminiException("No Gemini model is available right now.")
}
