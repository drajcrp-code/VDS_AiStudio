package com.vds.creativestudio

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

open class GeminiException(msg: String) : Exception(msg)
open class GeminiBusyException(msg: String = "The assistant is busy right now. Try again in a moment.") : GeminiException(msg)
class ClipException(msg: String) : Exception(msg)
class BusyException : Exception()
class KeyException : Exception()

// Tried in order. If the first model is not found, the next one is used.
private val GEMINI_MODELS = listOf("gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-3.5-flash")

private fun toBase64(b: Bitmap): String {
    val big = maxOf(b.width, b.height)
    val scale = minOf(1f, 1024f / big)
    val s = if (scale < 1f) Bitmap.createScaledBitmap(b, (b.width * scale).toInt(), (b.height * scale).toInt(), true) else b
    val out = ByteArrayOutputStream()
    s.compress(Bitmap.CompressFormat.JPEG, 80, out)
    return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
}

private fun buildBody(model: String, text: String, image: Bitmap?, search: Boolean, json: Boolean): String {
    val parts = JSONArray()
    if (image != null) {
        parts.put(JSONObject().put("inline_data",
            JSONObject().put("mime_type", "image/jpeg").put("data", toBase64(image))))
    }
    parts.put(JSONObject().put("text", text))
    val root = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
    val cfg = JSONObject().put("maxOutputTokens", if (json) 4000 else 1500)
    if (json && !search) cfg.put("responseMimeType", "application/json")
    // Turning thinking off makes the 2.5 Flash model answer much faster.
    if (model.startsWith("gemini-2.5-flash")) {
        cfg.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
    }
    root.put("generationConfig", cfg)
    if (search) root.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
    return root.toString()
}

private fun post(model: String, key: String, body: String): Pair<Int, String> {
    val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        .openConnection() as HttpURLConnection
    try {
        c.requestMethod = "POST"
        c.connectTimeout = 30000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", key.trim())
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val resp = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Pair(code, resp)
    } finally {
        c.disconnect()
    }
}

private fun parse(resp: String): String {
    val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
        .getJSONObject("content").getJSONArray("parts")
    val sb = StringBuilder()
    for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
    return sb.toString().trim().ifEmpty { throw GeminiException("The assistant sent an empty answer. Try again.") }
}

// Blocking call. Run it on a background thread (Dispatchers.IO).
// live = true asks Gemini to use Google Search for fresh facts. If that is not allowed it retries without.
fun geminiAsk(key: String, text: String, image: Bitmap? = null, live: Boolean = false, json: Boolean = false): String {
    if (key.isBlank()) throw GeminiException("The assistant is not set up yet. Owner: add the assistant key in You > Settings.")
    var busy = false
    var limited = false
    for (m in GEMINI_MODELS) {
        val tries = if (live) listOf(true, false) else listOf(false)
        for (search in tries) {
            val (code, resp) = post(m, key, buildBody(m, text, image, search, json))
            if (code in 200..299) return parse(resp)
            if (code == 500 || code == 502 || code == 503 || code == 504) {
                busy = true
                break
            }
            if (code == 429) {
                // Each model has its own free quota, so try the next one.
                limited = true
                break
            }
            if (search) continue
            when (code) {
                400, 401, 403 -> throw GeminiException("The assistant key was not accepted. Check it in You > Settings.")
                404 -> break
                else -> throw GeminiException("Assistant error $code.")
            }
        }
    }
    if (busy) throw GeminiBusyException()
    if (limited) throw GeminiBusyException("The assistant's free limit for today is used up. It resets daily.")
    throw GeminiException("No assistant model is available right now.")
}
