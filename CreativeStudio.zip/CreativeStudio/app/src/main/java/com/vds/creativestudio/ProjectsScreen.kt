package com.vds.creativestudio

import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun ProjectsScreen(onCreate: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val all = remember(tick) { Library.list(ctx) }
    var open by remember { mutableStateOf<Creation?>(null) }
    val current = open
    BackHandler(enabled = current != null) { open = null }

    if (current != null) {
        CreationViewer(current, onBack = { open = null }, onDelete = {
            Library.delete(current)
            open = null
            tick++
        })
    } else if (all.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            T("Projects", 24, bold = true)
            Spacer(Modifier.weight(1f))
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                T("Nothing saved yet", 18, bold = true)
                Spacer(Modifier.height(6.dp))
                T("Every image and clip you make is saved here.", 14, Muted)
                Spacer(Modifier.height(16.dp))
                Button(onClick = onCreate) { Text("Create Project") }
            }
            Spacer(Modifier.weight(1f))
        }
    } else {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                T("Projects", 24, bold = true)
                Spacer(Modifier.weight(1f))
                T("${all.size} saved", 13, Muted)
            }
            Spacer(Modifier.height(14.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(all) { c -> ThumbCard(c) { open = c } }
            }
        }
    }
}

@Composable
private fun ThumbCard(item: Creation, onClick: () -> Unit) {
    val bmp = remember(item.file.path) { Library.thumb(item) }
    Box(
        Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp))
            .background(CardBg).clickable(onClick = onClick)
    ) {
        if (bmp != null) {
            Image(bitmap = bmp.asImageBitmap(), contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        if (item.isVideo) {
            Icon(Icons.Filled.PlayArrow, contentDescription = "Video", tint = Color.White,
                modifier = Modifier.align(Alignment.Center).size(44.dp))
        }
    }
}

@Composable
private fun CreationViewer(item: Creation, onBack: () -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val thumb = remember(item.file.path) { Library.thumb(item) }
    val ratio = if (thumb != null && thumb.height > 0) thumb.width.toFloat() / thumb.height else 1f
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        ScreenHeader(if (item.isVideo) "Clip" else "Image", onBack)
        Spacer(Modifier.height(12.dp))
        if (item.isVideo) {
            LoopingVideo(
                modifier = Modifier.fillMaxWidth(if (ratio < 1f) 0.6f else 1f)
                    .aspectRatio(if (ratio > 0.2f) ratio else 16f / 9f)
                    .align(Alignment.CenterHorizontally)
                    .clip(RoundedCornerShape(16.dp)),
                path = item.file.path, muted = false
            )
        } else {
            val bmp = remember(item.file.path) { BitmapFactory.decodeFile(item.file.path) }
            if (bmp != null) {
                Image(bitmap = bmp.asImageBitmap(), contentDescription = "Saved image",
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)))
            }
        }
        if (item.prompt.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            T("Prompt", 13, Muted)
            SelectionContainer { T(item.prompt, 14, Color(0xFFC9CCE6)) }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = {
                    val ok = if (item.isVideo) {
                        saveVideoToGallery(ctx, item.file.path)
                    } else {
                        val b = BitmapFactory.decodeFile(item.file.path)
                        b != null && saveImageToGallery(ctx, b)
                    }
                    Toast.makeText(ctx, if (ok) "Saved to your gallery" else "Saving needs Android 10 or newer.", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f)
            ) { Text("Save to phone") }
            OutlinedButton(onClick = onDelete, modifier = Modifier.weight(1f)) { Text("Delete") }
        }
    }
}
