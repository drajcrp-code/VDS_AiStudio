package com.vds.creativestudio

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp

@Composable
fun LogoMark(dp: Dp) {
    Image(
        painter = painterResource(R.drawable.logo),
        contentDescription = "VDS AiStudio logo",
        modifier = Modifier.size(dp)
    )
}
