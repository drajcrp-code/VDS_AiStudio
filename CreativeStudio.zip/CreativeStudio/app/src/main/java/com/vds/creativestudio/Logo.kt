package com.vds.creativestudio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.Dp

@Composable
fun LogoMark(dp: Dp) {
    Canvas(Modifier.size(dp)) {
        val w = size.width
        drawRoundRect(
            brush = Brush.linearGradient(listOf(Color(0xFF7A3EC8), Color(0xFF3F6AD8))),
            cornerRadius = CornerRadius(w * 0.28f, w * 0.28f)
        )
        val play = Path().apply {
            moveTo(w * 0.38f, w * 0.27f)
            lineTo(w * 0.38f, w * 0.73f)
            lineTo(w * 0.74f, w * 0.50f)
            close()
        }
        drawPath(play, Color.White)
        val cx = w * 0.80f
        val cy = w * 0.22f
        val r = w * 0.10f
        val spark = Path().apply {
            moveTo(cx, cy - r)
            quadraticBezierTo(cx, cy, cx + r, cy)
            quadraticBezierTo(cx, cy, cx, cy + r)
            quadraticBezierTo(cx, cy, cx - r, cy)
            quadraticBezierTo(cx, cy, cx, cy - r)
            close()
        }
        drawPath(spark, Color.White)
    }
}
