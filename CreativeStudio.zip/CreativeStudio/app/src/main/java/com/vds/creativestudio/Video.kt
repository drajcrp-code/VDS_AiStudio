package com.vds.creativestudio

import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

// Scales the video so it fills the view and crops the extra part (like "centerCrop").
private fun cropToFill(tv: TextureView, vw: Int, vh: Int) {
    val w = tv.width.toFloat()
    val h = tv.height.toFloat()
    if (w <= 0f || h <= 0f || vw <= 0 || vh <= 0) return
    val scale = maxOf(w / vw, h / vh)
    val m = Matrix()
    m.setScale(vw * scale / w, vh * scale / h, w / 2f, h / 2f)
    tv.setTransform(m)
}

// Plays a video in a loop. Use rawRes for a clip inside the app, or path for a downloaded file.
@Composable
fun LoopingVideo(
    modifier: Modifier = Modifier, rawRes: Int? = null, path: String? = null, muted: Boolean = true
) {
    val ctx = LocalContext.current
    val holder = remember { arrayOfNulls<MediaPlayer>(1) }
    DisposableEffect(Unit) {
        onDispose {
            holder[0]?.release()
            holder[0] = null
        }
    }
    AndroidView(
        modifier = modifier,
        factory = { c ->
            val tv = TextureView(c)
            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                    try {
                        val mp = MediaPlayer()
                        holder[0] = mp
                        mp.setSurface(Surface(st))
                        if (rawRes != null) {
                            val afd = ctx.resources.openRawResourceFd(rawRes)
                            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                            afd.close()
                        } else if (path != null) {
                            mp.setDataSource(path)
                        }
                        mp.isLooping = true
                        if (muted) mp.setVolume(0f, 0f)
                        mp.setOnVideoSizeChangedListener { _, vw, vh -> cropToFill(tv, vw, vh) }
                        mp.setOnPreparedListener { it.start() }
                        mp.prepareAsync()
                    } catch (e: Exception) {
                        // If a video cannot play, the view stays empty.
                    }
                }

                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                    holder[0]?.release()
                    holder[0] = null
                    return true
                }

                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
            tv
        }
    )
}

// Google AdMob banner. It uses Google's test ad until you put your own ad unit id in Data.kt.
@Composable
fun BannerAd() {
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(60.dp),
        factory = { c ->
            AdView(c).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = AD_BANNER_ID
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}
