package com.vds.creativestudio

import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope

@Composable
fun ProjectScreen(initialPrompt: String, state: ProjectState, scope: CoroutineScope, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    val view = LocalView.current
    val owner = Store.owner(ctx)
    var sel by remember { mutableIntStateOf(0) }
    var prompt by remember { mutableStateOf(initialPrompt) }
    var vertical by remember { mutableStateOf(false) }
    var style by remember { mutableStateOf("Cinematic") }
    var localError by remember { mutableStateOf("") }
    val av = Store.avatar(ctx, sel)

    // Keep the screen awake while the video is being made.
    DisposableEffect(state.running) {
        view.keepScreenOn = state.running
        onDispose { view.keepScreenOn = false }
    }

    fun start() {
        localError = ""
        if (state.running) return
        if (prompt.isBlank()) {
            localError = "Type your idea or story first."
            return
        }
        if (!owner) {
            localError = "Create Project needs a subscription. Subscriptions are coming soon."
            return
        }
        focus.clearFocus()
        state.start(ctx, scope, prompt, sel, vertical, style)
    }

    ToolScreen(
        title = "Create Project", onBack = onBack,
        actionText = if (state.running) "Working..." else "Create 60 s video",
        busy = state.running, onAction = { start() }
    ) {
        Section("CHARACTER AND VOICE") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (0..3).forEach { i ->
                    Chip(selected = sel == i, onClick = { sel = i }, label = { Text(Store.avatar(ctx, i).name) })
                }
            }
            Spacer(Modifier.height(8.dp))
            T("${av.sex}, ${av.age} · Voice: ${av.style}", 13, Muted)
        }
        Spacer(Modifier.height(12.dp))
        Section("YOUR IDEA OR STORY") {
            PromptBox(prompt, { prompt = it }, "Describe your video, or paste a story...", 150)
            Spacer(Modifier.height(8.dp))
            AssistButton("project", prompt) { prompt = it }
        }
        Spacer(Modifier.height(12.dp))
        Section("LOOK") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Cinematic", "Realistic", "Anime", "3D").forEach { s ->
                    Chip(selected = style == s, onClick = { style = s }, label = { Text(s) })
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(selected = !vertical, onClick = { vertical = false }, label = { Text("Landscape 16:9") })
                Chip(selected = vertical, onClick = { vertical = true }, label = { Text("Portrait 9:16") })
            }
        }
        if (!owner) {
            Spacer(Modifier.height(12.dp))
            T("Create Project needs a subscription. Subscriptions are coming soon.", 14, Color(0xFFF5C76B))
        }
        if (state.running) {
            Spacer(Modifier.height(12.dp))
            Section("MAKING YOUR VIDEO") {
                T(state.status, 15)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                T("This takes a few minutes. Keep the app open.", 13, Muted)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { state.cancel() }, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
            }
        }
        if (localError.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            T(localError, 14, Color(0xFFFF9A9A))
        }
        state.error?.let {
            Spacer(Modifier.height(12.dp))
            T(it, 14, Color(0xFFFF9A9A))
        }
        if (state.note.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            T(state.note, 13, Color(0xFFF5C76B))
        }
        state.resultPath?.let { path ->
            Spacer(Modifier.height(12.dp))
            Section("YOUR VIDEO") {
                key(path) {
                    LoopingVideo(
                        modifier = Modifier.fillMaxWidth(if (vertical) 0.6f else 1f)
                            .aspectRatio(if (vertical) 9f / 16f else 16f / 9f)
                            .align(Alignment.CenterHorizontally)
                            .clip(RoundedCornerShape(14.dp)),
                        path = path, muted = false
                    )
                }
                Spacer(Modifier.height(10.dp))
                T("Saved in Projects", 13, Muted)
                Spacer(Modifier.height(6.dp))
                OutlinedButton(
                    onClick = {
                        val ok = saveVideoToGallery(ctx, path)
                        Toast.makeText(ctx, if (ok) "Saved to Movies/VDSAistudio" else "Saving needs Android 10 or newer.", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Save to phone") }
            }
        }
    }
}
