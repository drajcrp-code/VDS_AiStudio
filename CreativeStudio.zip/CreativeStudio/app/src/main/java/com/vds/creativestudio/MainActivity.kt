package com.vds.creativestudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioTheme { StudioApp() } }
    }
}

@Composable
fun StudioApp() {
    var tab by remember { mutableIntStateOf(0) }
    val items = listOf(
        "Home" to Icons.Filled.Home,
        "Projects" to Icons.Filled.Folder,
        "Avatars" to Icons.Filled.Face,
        "Settings" to Icons.Filled.Settings,
        "You" to Icons.Filled.Person
    )
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF171830)) {
                items.forEachIndexed { i, (name, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = name) },
                        label = { Text(name) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            if (tab == 0) HomeScreen() else PlaceholderScreen(items[tab].first)
        }
    }
}
