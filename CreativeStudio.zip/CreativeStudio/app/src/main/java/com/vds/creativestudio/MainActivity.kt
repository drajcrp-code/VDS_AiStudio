package com.vds.creativestudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioTheme { StudioApp() } }
    }
}

@Composable
fun StudioApp() {
    var tab by remember { mutableIntStateOf(0) }
    var screen by remember { mutableStateOf("") }
    var edit by remember { mutableIntStateOf(0) }
    var prefill by remember { mutableStateOf("") }
    val items = listOf(
        "Home" to Icons.Filled.Home,
        "Projects" to Icons.Filled.Folder,
        "Avatars" to Icons.Filled.Face,
        "Settings" to Icons.Filled.Settings,
        "You" to Icons.Filled.Person
    )
    BackHandler(enabled = screen != "") { screen = "" }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF171830)) {
                items.forEachIndexed { i, (name, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i; screen = "" },
                        icon = { Icon(icon, contentDescription = name) },
                        label = { Text(name) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when {
                screen == "image" -> ImageScreen { screen = "" }
                screen == "video" -> VideoScreen { screen = "" }
                screen == "project" -> ProjectScreen(prefill) { screen = "" }
                screen == "edit" -> EditAvatarScreen(edit) { screen = "" }
                tab == 0 -> HomeScreen(
                    onImage = { screen = "image" },
                    onVideo = { screen = "video" },
                    onProject = { prefill = ""; screen = "project" },
                    onSuggestion = { p -> prefill = p; screen = "project" }
                )
                tab == 1 -> ProjectsScreen { prefill = ""; screen = "project" }
                tab == 2 -> AvatarsScreen { i -> edit = i; screen = "edit" }
                tab == 3 -> SettingsScreen()
                else -> YouScreen()
            }
        }
    }
}
