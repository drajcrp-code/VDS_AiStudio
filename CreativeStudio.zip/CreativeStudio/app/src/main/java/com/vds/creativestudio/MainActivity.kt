package com.vds.creativestudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.ads.MobileAds

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            MobileAds.initialize(this) {}
        } catch (e: Exception) {
            // Ads are optional. The app works without them.
        }
        setContent { StudioTheme { StudioApp() } }
    }
}

// The glowing round button in the middle of the bottom menu.
@Composable
fun GlowOrb() {
    val t = rememberInfiniteTransition(label = "glow")
    val pulse by t.animateFloat(
        initialValue = 0.55f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(Modifier.size(54.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier.size(54.dp)
                .graphicsLayer {
                    scaleX = 0.8f + 0.3f * pulse
                    scaleY = 0.8f + 0.3f * pulse
                    alpha = pulse * 0.8f
                }
                .background(Brush.radialGradient(listOf(Color(0xFFA68CFF), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier.size(38.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF9B7BFF), Color(0xFF4FA8FF)))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
fun RowScope.AssistantNavItem(selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).fillMaxHeight().clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        GlowOrb()
        Text("Assistant", fontSize = 12.sp, color = if (selected) Color.White else Muted)
    }
}

@Composable
fun RowScope.NavItem(selected: Boolean, label: String, icon: ImageVector, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected, onClick = onClick,
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label) }
    )
}

@Composable
fun StudioApp() {
    val ctx = LocalContext.current
    val appScope = rememberCoroutineScope()
    val assistant = remember { AssistantState() }
    var tab by remember { mutableIntStateOf(0) }
    var screen by remember { mutableStateOf("") }
    var edit by remember { mutableIntStateOf(0) }
    var prefill by remember { mutableStateOf("") }
    var imagePrefill by remember { mutableStateOf("") }

    BackHandler(enabled = screen != "" || tab != 0) {
        if (screen != "") screen = "" else tab = 0
    }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF171830)) {
                NavItem(tab == 0, "Home", Icons.Filled.Home) { tab = 0; screen = "" }
                NavItem(tab == 1, "Projects", Icons.Filled.Folder) { tab = 1; screen = "" }
                AssistantNavItem(tab == 2) { tab = 2; screen = "" }
                NavItem(tab == 3, "Avatars", Icons.Filled.Face) { tab = 3; screen = "" }
                NavItem(tab == 4, "You", Icons.Filled.Person) { tab = 4; screen = "" }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when {
                screen == "image" -> ImageScreen(imagePrefill) { screen = "" }
                screen == "video" -> VideoScreen { screen = "" }
                screen == "project" -> ProjectScreen(prefill) { screen = "" }
                screen == "edit" -> EditAvatarScreen(edit) { screen = "" }
                tab == 0 -> HomeScreen(
                    onImage = { imagePrefill = ""; screen = "image" },
                    onVideo = { screen = "video" },
                    onProject = { prefill = ""; screen = "project" },
                    onSuggestion = { p -> prefill = p; screen = "project" }
                )
                tab == 1 -> ProjectsScreen { prefill = ""; screen = "project" }
                tab == 2 -> AssistantScreen(
                    assistant, appScope, onBack = { tab = 0 },
                    onUseForImage = { t -> imagePrefill = t; screen = "image" },
                    onUseForProject = { t -> prefill = t; screen = "project" }
                )
                tab == 3 -> AvatarsScreen { i -> edit = i; screen = "edit" }
                else -> YouScreen()
            }
        }
    }
}
